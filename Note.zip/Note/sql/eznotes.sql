-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3307
-- Generation Time: Dec 03, 2023 at 05:20 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `eznotes`
--

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE `comment` (
  `comment_id` int(11) NOT NULL,
  `comment_content` text NOT NULL,
  `comment_date` date NOT NULL DEFAULT current_timestamp(),
  `is_edited` varchar(200) DEFAULT NULL,
  `studentID` int(11) NOT NULL,
  `subject_id` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`comment_id`, `comment_content`, `comment_date`, `is_edited`, `studentID`, `subject_id`) VALUES
(14, 'Very informative! I\'d be honored to take this opportunity :)\n', '2023-12-02', 'edited', 2020, 'HST341'),
(56, 'Hello there!', '2023-12-03', NULL, 2021, 'HST341'),
(58, 'hello', '2023-12-03', NULL, 2020, 'CSC300');

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE `files` (
  `file_id` int(11) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `topic_id` int(11) DEFAULT NULL,
  `file_path` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `files`
--

INSERT INTO `files` (`file_id`, `file_name`, `topic_id`, `file_path`) VALUES
(62, 'MyTown.mp3', 6, '/Note/content/assets/files/HST341/6/My Castle Town.mp3'),
(63, 'My Castle Town.mp3', 6, '/Note/content/assets/files/HST341/6/My Castle Town.mp3'),
(64, 'Screenshot 2023-11-27 212300.png', 10, '/Note/content/assets/files/HST341/10/Screenshot 2023-11-27 212300.png'),
(65, 'Screenshot 2023-11-27 212300.png', 70, '/Note/content/assets/files/SCI123/70/Screenshot 2023-11-27 212300.png'),
(66, 'Screenshot 2023-11-27 082515.png', 10, '/Note/content/assets/files/HST341/10/Screenshot 2023-11-27 082515.png'),
(67, 'My Castle Town.mp3', 64, '/Note/content/assets/files/SCI123/64/My Castle Town.mp3'),
(68, 'My Castle Town.mp3', 9, '/Note/content/assets/files/HST341/9/My Castle Town.mp3');

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `subject_id` varchar(50) NOT NULL,
  `subject_name` varchar(255) NOT NULL,
  `subject_created` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `num_topics` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`subject_id`, `subject_name`, `subject_created`, `num_topics`) VALUES
('CSC300', 'DATA STRUCTURE MANAGEMENT', '2023-12-01 12:05:26', 0),
('CSC305', 'PROGRAMMING PARADIGMS', '2023-11-27 04:23:28', 0),
('HST341', 'HISTORY', '2023-12-01 09:09:33', 5),
('SCI123', 'SCIENCE AND CHEMISTRY', '2023-12-01 09:09:33', 5);

-- --------------------------------------------------------

--
-- Table structure for table `topics`
--

CREATE TABLE `topics` (
  `topic_id` int(11) NOT NULL,
  `topic_name` varchar(255) NOT NULL,
  `subject_id` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `topics`
--

INSERT INTO `topics` (`topic_id`, `topic_name`, `subject_id`) VALUES
(6, ' Civilizations', 'HST341'),
(7, 'Medieval History Argumentation', 'HST341'),
(8, 'Modern History', 'HST341'),
(9, 'World Wars', 'HST341'),
(10, 'Renaissance', 'HST341'),
(60, 'Chapter 3', 'SCI123'),
(64, 'Chapter 4', 'SCI123'),
(66, 'Chapter 2', 'SCI123'),
(69, 'Chapter 1', 'SCI123'),
(70, 'Chapter 5', 'SCI123');

--
-- Triggers `topics`
--
DELIMITER $$
CREATE TRIGGER `update_num_topics` AFTER INSERT ON `topics` FOR EACH ROW BEGIN
    UPDATE subjects s
    SET num_topics = (SELECT COUNT(*) FROM topics WHERE subject_id = NEW.subject_id)
    WHERE s.subject_id = NEW.subject_id;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `update_num_topics_after_delete` AFTER DELETE ON `topics` FOR EACH ROW BEGIN
    UPDATE subjects s
    SET num_topics = (SELECT COUNT(*) FROM topics WHERE subject_id = s.subject_id)
    WHERE s.subject_id = OLD.subject_id;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `studentID` int(11) NOT NULL,
  `fullname` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `userimage` varchar(200) NOT NULL,
  `userType` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`studentID`, `fullname`, `email`, `password`, `userimage`, `userType`) VALUES
(2020, 'Sheila Munirah Randy', 'Sheila@yahoo.com', 'small', '/Note/content/assets/images/userprofilepicture/2020.png', 'user'),
(2021, 'Adam Alif Bin Irsyad', 'big@yahoo.com', 'big', '/Note/content/assets/images/userprofilepicture/2021.png', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`comment_id`),
  ADD KEY `fk_comment_user` (`studentID`),
  ADD KEY `fk_comment_subjects` (`subject_id`);

--
-- Indexes for table `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`file_id`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`subject_id`);

--
-- Indexes for table `topics`
--
ALTER TABLE `topics`
  ADD PRIMARY KEY (`topic_id`),
  ADD KEY `fk_topics_subjects` (`subject_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`studentID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comment`
--
ALTER TABLE `comment`
  MODIFY `comment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT for table `files`
--
ALTER TABLE `files`
  MODIFY `file_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=71;

--
-- AUTO_INCREMENT for table `topics`
--
ALTER TABLE `topics`
  MODIFY `topic_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=77;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `comment`
--
ALTER TABLE `comment`
  ADD CONSTRAINT `fk_comment_subjects` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`subject_id`),
  ADD CONSTRAINT `fk_comment_user` FOREIGN KEY (`studentID`) REFERENCES `user` (`studentID`);

--
-- Constraints for table `topics`
--
ALTER TABLE `topics`
  ADD CONSTRAINT `fk_topics_subjects` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`subject_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `topics_ibfk_1` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`subject_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
