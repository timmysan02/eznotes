<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="./assets/css/styles.css" />
    <link rel="stylesheet" href="./assets/css/style.css" />
	<title>Note</title>
</head>
<body>
<div class="overlay" id="overlay"></div>

    <header class="main-header">
        <div class="main-header-section-one">
        <a href="homepage.php">
        <img class="main-logo" src="/Note/content/assets/images/mainlogo.png" alt="Main Logo">
        </a>
       
        <a href="dashboard.php" class="main-header-links">Subjects</a>
        <a class="main-header-links">Learn</a>
        <a class="main-header-links">Explore</a>
        </div>

        <?php if (isset($_SESSION['admin'])) {

        echo '<div class="main-header-section-two">';
        echo '<button class="add-new-folder" id="addSubjectButton">';
         echo '<img src="/Note/content/assets/images/add.jpg">';
         echo '<span>Add new</span>';
        echo '</button>';

        }?>

     
  
        <?php
        $sessionData = $_SESSION['user'] ?? $_SESSION['admin'] ?? null;

        if (is_array($sessionData)) :
            // Assuming $_SESSION['user']['fullname'] is "Alexander Johns" or $_SESSION['admin']['fullname'] is "John Doe"
            $fullName = $sessionData['fullname'];
            // Split the full name into an array of words
            $fullNameArray = explode(' ', $fullName);
            // Take the first element as the first name
            $firstName = $fullNameArray[0];

            $imagePath = isset($_SESSION['user']) ? '/Note/content/assets/images/user.png' : '/Note/content/assets/images/admin.png';
        ?>
            <button class="user_profile" onclick="toggleUserOptionstwo(event)">
                <div class="circular-user-profile">
                <img src="<?php echo $userImage; ?>">
                </div>
                <span><?php echo $firstName; ?></span>

                <div class="user-options2-container">
                <ul>
                    <li class="manage-account" onclick="redirectusersettings()">Manage account</li>
                    <hr>
                    <li  class="logout-btn" onclick="logout()">Logout</li>
                    <!-- Add more options as needed -->
                </ul>
            </div>


            </button>

        <?php else : ?>
            <a href="signin.php" class="login-main-header-button"> Login</a>
        <?php endif; ?>

        </div>
    </header>

    <div class="add-subject-container" id="addSubjectContainer">
            <div class="header-and-close">
            <h3>Create a new subject</h3>
            <img class="info-image" src="/Note/content/assets/images/info.png">
            <button id="closeButton">
            <img class="close-addcontainer" src="/Note/content/assets/images/close.png">
            </button>
            </div>
            <form action="" method="POST">

            <div class="subject-container">
                <div class="subjectid">
                <label>Subject ID</label>
                <input id="addsubjectid-input" type="text" name="add_subjectid">
                </div>

                <div class="addsubjectid-message-alert" id="addsubjectid-message-alert">
                     <p>
                         <i class="fas fa-exclamation-triangle"></i> Subject ID already exist.
                    </p>
                </div>


                <div class="subjectname">
                    <label>Name</label>
                    <input type="text" name="add_subjectname">
                </div>

                <div class="cancel-create-btn">
                    <input type="checkbox">
                    <span>Open subject</span>
                    <button id="cancelButton">Cancel</button>
                    <button id="addsubject-btn" name="addsubjectbtn" disabled>Create</button>
                </div>
            </div>
        </form>

    </div>


    <div class="edit-subject-container" id="editSubjectContainer">
            <div class="header-and-close">
            <h3>Edit subject</h3>
            <img class="edit-info-image" src="/Note/content/assets/images/info.png">
            <button id="editcontainer-closeButton">
            <img class="close-editcontainer" src="/Note/content/assets/images/close.png">
            </button>
            </div>
            <form action="" method="POST">
            <div class="subject-container">
                <div class="subjectid" hidden>
                <label>Subject ID</label>
                <input id="editsubjectid-input" type="text" name="edit_subject_id">
                </div>

                <div class="editsubjectid-message-alert" id="editsubjectid-message-alert">
                     <p>
                         <i class="fas fa-exclamation-triangle"></i> Subject ID already exist.
                    </p>
                </div>

                <div class="subjectname">
                    <label>Name</label>
                    <input type="text" name="edit_subject_name">
                </div>

                <div class="cancel-edit-btn">
                    <button class="editcancelbtn" id="editcontainer-cancelButton">Cancel</button>
                    <button class="confirmedit" id="editsubject-button" name="editsubjectbtn" disabled>Edit</button>


                </div>
            </div>
        </form>

    </div>


    <div class="delete-subject-container" id="deleteSubjectContainer">
            <div class="header-and-close">
            <h3>Delete?</h3>
            <button id="deletecontainer-closeButton">
            <img class="close-editcontainer" src="/Note/content/assets/images/close.png">
            </button>
            </div>
            <form action="" method="POST">
            <div class="subject-container">
                <div class="subjectid" hidden>
                <label>Subject ID</label>
                <input id="delete_subject_json" type="hidden" name="delete_subject_json">
                <input id="editsubjectid-input" type="text" name="delete_subject_id">
                </div>


                <p id="deleteSubjectMessage">Are you sure you want to delete the subject '<span id="subjectIdPlaceholder"></span>'. This action cannot be undone.</p>



                <div id="cancel-delete-container" class="cancel-edit-btn">
                    <button class="confirmdelete" id="deletesubject-button" name="deletesubjectbtn">Delete</button>
                    <button class="deletecancelbtn" id="deletecontainer-cancelButton">Cancel</button>
                </div>
            </div>
        </form>

    </div>


    <div class="delete-topic-container" id="deleteTopicContainer">
            <div class="header-and-close">
            <h3 style="margin-right: 360px;">Delete?</h3>
            <button id="deletetopiccontainer-closeButton">
            <img class="close-editcontainer" src="/Note/content/assets/images/close.png">
            </button>
            </div>

            <div class="subject-container">
                <div class="subjectid" hidden>
                <label>Subject ID</label>
                <input id="delete_subject_json" type="hidden" name="delete_subject_json">
                <input id="editsubjectid-input" type="text" name="delete_subject_id">
                </div>


                <p style="margin-left:30px; margin-bottom:80px;" id="deleteSubjectMessage">Are you sure you want to delete the topic '<span id="selected-topicdelete"></span>'. This action cannot be undone.</p>



                <div id="cancel-delete-container" class="cancel-edit-btn">
                    <button class="confirmdelete" id="deletetopic-button" name="deletetopicbtn">Delete</button>
                    <button class="deletecancelbtn" id="deletecontainertopic-cancelButton">Cancel</button>
                </div>
            </div>
    </div>


    <div class="delete-file-container" id="deletefileContainer">
            <div class="header-and-close">
            <h3 style="margin-right: 360px;">Delete?</h3>
            <button id="deletefilecontainer-closeButton">
            <img class="close-editcontainer" src="/Note/content/assets/images/close.png">
            </button>
            </div>

                <p style="margin-left:20px; margin-bottom:80px;" id="deleteSubjectMessage">Are you sure you want to delete the file '<span id="selected-filedelete"></span>'. This action cannot be undone.</p>

                <div id="cancel-delete-container" class="cancel-edit-btn">
                    <button class="confirmdelete" id="deletefile-button" name="deletefilebtn">Delete</button>
                    <button class="deletecancelbtn" id="deletecontainerfile-cancelButton">Cancel</button>
                </div>
            </div>
    </div>


    <div class="must-login-container" id="mustlogincontainer">
            <div class="header-and-close">
            <button style="margin-left: 535px;" id="closelogincontainer-closeButton">
            <img style="height: 15px; width:15px;" class="close-must-login-container" src="/Note/content/assets/images/close.png">
            </button>
            </div>

                <p style="font-size:14px; font-weight:500; margin-left:110px; margin-top:30px; margin-bottom: 80px;" id="deleteSubjectMessage">Please Login to get access to our wonderful notes!</p>
                <a style="margin-left: 205px; margin-top:-20px;" href="signin.php">Click here to login</a>
                <span style="opacity: 0;">a</span>

          
            </div>




    </div>



    


    <script src="./assets/js/addsubjects.js"></script>
    <script src="./assets/js/useroptions.js"></script>
    <script src="./assets/js/usersettings.js"></script>
    <script src="./assets/js/logout.js"></script>

</body>
</html>