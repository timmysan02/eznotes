var openEditContainer = null;
var editButtons = document.getElementsByClassName('edit-btn');
var editSubjectIdInput = document.getElementsByName('edit_subject_id')[0];
var editSubjectNameInput = document.getElementsByName('edit_subject_name')[0];
var editSubjectContainer = document.getElementById('editSubjectContainer');
var overlay = document.getElementById('overlay');
var closeButton = document.getElementById('editcontainer-closeButton');

// Function to fetch subject information and populate the edit container
function fetchSubjectInformationForEdit(subjectId) {
    // Create a new XMLHttpRequest object
    var xhr = new XMLHttpRequest();

    // Define the PHP script URL
    var phpScriptURL = 'functions.php';

    // Prepare the data to be sent
    var data = 'action=get_subject_info&subject_id=' + encodeURIComponent(subjectId);

    // Set up the request
    xhr.open('POST', phpScriptURL, true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

    // Define the callback function to handle the response
    xhr.onreadystatechange = function () {
        if (xhr.readyState === XMLHttpRequest.DONE) {
            if (xhr.status === 200) {
                // Log the raw response
     

                // Parse the JSON data from the response
                var subjectArray = JSON.parse(xhr.responseText);

                // Assuming the first subject in the array is the relevant one
                var selectedSubject = subjectArray[0];

                // Access the required values from the selected subject
                var selectedSubjectId = selectedSubject.subject_id;
                var selectedSubjectName = selectedSubject.subject_name;

                // Populate the input fields in the edit container
                editSubjectIdInput.value = selectedSubjectId;
                editSubjectNameInput.value = selectedSubjectName;

                // Toggle the 'visible' class for the edit container and overlay
                editSubjectContainer.classList.toggle('visible');
                overlay.classList.toggle('visible');
                openEditContainer = editSubjectContainer.classList.contains('visible') ? editSubjectContainer : null;
            } else {
                console.error('Error fetching subject information:', xhr.status);
            }
        }
    };

    // Send the request with the data
    xhr.send(data);
}

// Iterate through each 'edit-btn' and attach the event listener
for (var i = 0; i < editButtons.length; i++) {
    editButtons[i].addEventListener('click', function (e) {
        // Find the corresponding 'edit-subject-container' based on the button's ID
        var editBtnId = this.id;

        // Extract subject ID from the button's ID
        var subjectId = editBtnId.replace('editBtn_', '');

        // Call the function to fetch subject information and populate the edit container
        fetchSubjectInformationForEdit(subjectId);

        // Stop the click event from propagating to the document
        e.stopPropagation();
    });
}

// Add a mousedown event listener to the overlay to close the edit container when clicking outside
overlay.addEventListener('mousedown', function (e) {
    if (openEditContainer && !openEditContainer.contains(e.target)) {
        openEditContainer.classList.remove('visible');
        overlay.classList.remove('visible');
        openEditContainer = null;
    }
});

// Add an event listener for the close button
closeButton.addEventListener('click', function () {
    if (openEditContainer) {
        openEditContainer.classList.remove('visible');
        overlay.classList.remove('visible');
        openEditContainer = null;
    }
});
