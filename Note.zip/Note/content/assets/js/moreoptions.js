// Get all elements with the class 'more-options-button'
var moreOptionsButtons = document.getElementsByClassName('more-options-button');
var favouriteButton = document.getElementById('favouriteButton');
// Iterate through each 'more-options-button' and attach the event listener
for (var i = 0; i < moreOptionsButtons.length; i++) {
    moreOptionsButtons[i].addEventListener('click', function(e) {
        event.preventDefault();
        // Find the corresponding 'more-options-container' based on the button's ID
        var containerId = this.id + '_container';
        var moreOptionsContainer = document.getElementById(containerId);

        // Close all other open containers
        var allContainers = document.getElementsByClassName('more-options-container');
        for (var j = 0; j < allContainers.length; j++) {
            if (allContainers[j] !== moreOptionsContainer) {
                allContainers[j].classList.remove('visible');
            }
        }

        // Toggle the 'visible' class for the clicked container
        if (moreOptionsContainer) {
            moreOptionsContainer.classList.toggle('visible');
        }

        // Stop the click event from propagating to the document
        e.stopPropagation();
    });
}

// Add a click event listener to the document to close the container when clicking outside
document.addEventListener('click', function() {
    // Iterate through each 'more-options-container' and hide them
    var moreOptionsContainers = document.getElementsByClassName('more-options-container');
    for (var i = 0; i < moreOptionsContainers.length; i++) {
        moreOptionsContainers[i].classList.remove('visible');
    }
});


favouriteButton.addEventListener('click', function (event) {
  
    event.preventDefault();


   
});
