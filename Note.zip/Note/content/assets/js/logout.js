function logout() {
    // Redirect the user to logout.php
    window.location.href = 'logout.php';
}