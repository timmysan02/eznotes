var openAddContainer = null;

// Add a click event listener to the document to close the add container when clicking outside
document.addEventListener('click', function() {
    // Close the currently open add container (if any)
    if (openAddContainer) {
        console.log('Closing Container ID (outside click):', openAddContainer.id);
        openAddContainer.classList.remove('visible');
        overlay.classList.remove('visible');
        openAddContainer = null;
    }
});

var addButton = document.getElementById('addSubjectButton');
var addSubjectContainer = document.getElementById('addSubjectContainer');
var overlay = document.getElementById('overlay');

document.getElementById('cancelButton').addEventListener('click', function(e) {


    addSubjectContainer.classList.remove('visible');
    overlay.classList.remove('visible');
    // Stop the click event from propagating to the document
    e.stopPropagation();
});

document.getElementById('closeButton').addEventListener('click', function(e) {

    addSubjectContainer.classList.remove('visible');
    overlay.classList.remove('visible');
    // Stop the click event from propagating to the document
    e.stopPropagation();
});

addButton.addEventListener('click', function(e) {
    addSubjectContainer.classList.toggle('visible');
    overlay.classList.toggle('visible');
    openAddContainer = addSubjectContainer.classList.contains('visible') ? addSubjectContainer : null;
    // Stop the click event from propagating to the document
    e.stopPropagation();
});

// Add an additional event listener to prevent propagation when clicking inside the container
addSubjectContainer.addEventListener('click', function(e) {
    e.stopPropagation();
});
