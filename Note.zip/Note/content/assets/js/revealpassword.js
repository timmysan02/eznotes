$(document).ready(function () {
    $("#showPasswordButton").on("click", function (event) {
        // Prevent the default form submission behavior
        event.preventDefault();

        var passwordInput = $("#passwordInput");
        var passwordRevealImage = $("#showPasswordButton img");

        // Toggle password visibility
        if (passwordInput.attr("type") === "password") {
            passwordInput.attr("type", "text");
            passwordRevealImage.attr("src", "/Note/content/assets/images/hidepassword.png");
        } else {
            passwordInput.attr("type", "password");
            passwordRevealImage.attr("src", "/Note/content/assets/images/showpassword.png");
        }
    });
});