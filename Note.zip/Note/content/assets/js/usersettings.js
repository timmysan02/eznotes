function redirectusersettings() {
    // Redirect the user to usersettings.php
    window.location.href = 'usersettings.php';
}