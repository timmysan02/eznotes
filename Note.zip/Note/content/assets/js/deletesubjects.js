var openDeleteContainer = null;
var deleteButtons = document.getElementsByClassName('delete-btn');
var overlay = document.getElementById('overlay');
var deleteContainer = document.getElementById('deleteSubjectContainer');
var closeButton = document.getElementById('deletecontainer-closeButton');

// Function to populate the delete container with subject information
function populateDeleteContainer(subjectJson) {
    // Assuming you have an input field for subject JSON in the delete container
    var deleteSubjectJsonInput = document.getElementsByName('delete_subject_json')[0];
    deleteSubjectJsonInput.value = subjectJson;

    // Parse the subject JSON
    var subjectData = JSON.parse(subjectJson);

    // Update the subject ID placeholder in the message
    var subjectIdPlaceholder = document.getElementById('subjectIdPlaceholder');
    if (subjectIdPlaceholder) {
        subjectIdPlaceholder.textContent = subjectData.subject_id;
    }

    // Toggle the 'visible' class for the delete container and overlay
    deleteContainer.classList.toggle('visible');
    overlay.classList.toggle('visible');
    openDeleteContainer = deleteContainer.classList.contains('visible') ? deleteContainer : null;

    console.log('Delete button clicked. Subject JSON:', subjectJson);
}

// Iterate through each 'delete-btn' and attach the event listener
for (var i = 0; i < deleteButtons.length; i++) {
    deleteButtons[i].addEventListener('click', function (e) {
        // Stop the click event from propagating to the document
        e.stopPropagation();

        // Extract subject JSON from the data-subject-json attribute
        var subjectJson = this.getAttribute('data-subject-json');

        // Call the function to populate the delete container with subject information
        populateDeleteContainer(subjectJson);
    });
}

// Add a mousedown event listener to the overlay to close the delete container when clicking outside
overlay.addEventListener('mousedown', function (e) {
    if (openDeleteContainer && !openDeleteContainer.contains(e.target)) {
        openDeleteContainer.classList.remove('visible');
        overlay.classList.remove('visible');
        openDeleteContainer = null;
    }
});

// Add an event listener for the close button
closeButton.addEventListener('click', function () {
    if (openDeleteContainer) {
        openDeleteContainer.classList.remove('visible');
        overlay.classList.remove('visible');
        openDeleteContainer = null;
    }
});
