function toggleUserOptions(e) {
    var userOptionsContainer = document.querySelector('.user-options-container');
    
    // Toggle the 'visible' class
    if (userOptionsContainer.classList.contains('visible')) {
        userOptionsContainer.classList.remove('visible');
    } else {
        userOptionsContainer.classList.add('visible');
    }

    // Stop event propagation to prevent the click event from reaching the document
    e.stopPropagation();
}

function clickOutsideHandler(e) {
    var userOptionsContainer = document.querySelector('.user-options-container');
    var userOptionsContainertwo = document.querySelector('.user-options2-container');
    
    // Check if the container is visible and the clicked element is not inside the container before hiding it
    if (userOptionsContainer.classList.contains('visible') && !userOptionsContainer.contains(event.target)) {
        userOptionsContainer.classList.remove('visible');
    }
}

function clickOutsideHandlerTwo(e) {
    var userOptionsContainertwo = document.querySelector('.user-options2-container');
    
    // Check if the container is visible and the clicked element is not inside the container before hiding it
    if (userOptionsContainertwo.classList.contains('visible') && !userOptionsContainertwo.contains(event.target)) {
        userOptionsContainertwo.classList.remove('visible');
    }
}

function toggleUserOptionstwo(e) {
    var userOptionsContainertwo = document.querySelector('.user-options2-container');
    
    // Toggle the 'visible' class
    if (userOptionsContainertwo.classList.contains('visible')) {
        userOptionsContainertwo.classList.remove('visible');
    } else {
        userOptionsContainertwo.classList.add('visible');
    }

    // Stop event propagation to prevent the click event from reaching the document
    e.stopPropagation();
}

// Add a click event listener to the document for event propagation
document.addEventListener('click', clickOutsideHandler);

// Add a click event listener to the second container for event propagation
document.addEventListener('click', clickOutsideHandlerTwo);