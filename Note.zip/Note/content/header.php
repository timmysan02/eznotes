<?php include 'server.php';?>
<?php include 'functions.php';?>
<?php session_start();
$userImage = $_SESSION['admin']['userimage'] ?? $_SESSION['user']['userimage'] ?? '';
$userStudentID = $_SESSION['admin']['studentID'] ?? $_SESSION['user']['studentID'] ?? '';
$fullname = $_SESSION['admin']['fullname'] ?? $_SESSION['user']['fullname'] ?? '';
$email = $_SESSION['admin']['email'] ?? $_SESSION['user']['email'] ?? '';
$studentpassword = $_SESSION['admin']['password'] ?? $_SESSION['user']['password'] ?? '';

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="./assets/css/styles.css" />
    <link rel="stylesheet" href="./assets/css/style.css" />
	<title>Note</title>
</head>
<body>
    <header class="main-header">
        <div class="main-header-section-one">
        <a href="homepage.php">
        <div class="main-logo-container">
        <img class="main-logo" src="/Note/content/assets/images/mainlogo.png" alt="Main Logo">
        </div>
        </a>
       
        <a href="dashboard.php" class="main-header-links">Subjects</a>
        <a class="main-header-links">Learn</a>
        <a class="main-header-links">Explore</a>
        </div>

        <div class="main-header-section-two">
        <button class="navbar-search">
        <span class="search-text">Search documentation...</span>
        <kbd class="kbd-searchbar">
            Ctrl + K
        </kbd>

        <div class="user-options-container">
                <ul>
                    <li class="manage-account" onclick="redirectusersettings()">Manage account</li>
                    <hr>
                    <li  class="logout-btn" onclick="logout()">Logout</li>
                    <!-- Add more options as needed -->
                </ul>
            </div>
        </button>

      

        <?php
        $sessionData = $_SESSION['user'] ?? $_SESSION['admin'] ?? null;

        if (is_array($sessionData)) :
            // Assuming $_SESSION['user']['fullname'] is "Alexander Johns" or $_SESSION['admin']['fullname'] is "John Doe"
            $fullName = $sessionData['fullname'];
            // Split the full name into an array of words
            $fullNameArray = explode(' ', $fullName);
            // Take the first element as the first name
            $firstName = $fullNameArray[0];

            $imagePath = isset($_SESSION['user']) ? '/Note/content/assets/images/user.png' : '/Note/content/assets/images/admin.png';
        ?>
            <button class="user_profile" onclick="toggleUserOptions(event)">
                <div class="circular-user-profile">
                <img src="<?php echo $userImage; ?>">
                </div>
                <span><?php echo $firstName; ?></span>
            </button>

        <?php else : ?>
            <a href="signin.php" class="login-main-header-button"> Login</a>
        <?php endif; ?>


        </div>
    </header>

    


            <script src="./assets/js/useroptions.js"></script>
            <script src="./assets/js/usersettings.js"></script>
            <script src="./assets/js/logout.js"></script>

</body>
</html>