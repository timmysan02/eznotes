<?php
    $servername = "localhost"; //server name and port
    $username = "root"; //database username
    $password = ""; //database password
    $dbname = "eznotes"; //database name

    // Create a database connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check for connection errors
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Set the character set
    mysqli_set_charset($conn, "utf8");
    ?>
