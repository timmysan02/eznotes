<?php
include 'functions.php';
session_start();
RetrieveAllUsersForEdit($conn);


$userImage = $_SESSION['admin']['userimage'] ?? $_SESSION['user']['userimage'] ?? '';
$userStudentID = $_SESSION['admin']['studentID'] ?? $_SESSION['user']['studentID'] ?? '';
$fullname = $_SESSION['admin']['fullname'] ?? $_SESSION['user']['fullname'] ?? '';
$email = $_SESSION['admin']['email'] ?? $_SESSION['user']['email'] ?? '';
$studentpassword = $_SESSION['admin']['password'] ?? $_SESSION['user']['password'] ?? '';



 ?>

<?php 
if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["edit-userdetails-btn"])) {
    // Call the editaccount function
    editaccount($conn);
}
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="./assets/css/styles.css" />
    <link rel="stylesheet" href="./assets/css/style.css" />
	<link rel="icon" href="/Note/content/assets/images/tablogo.jpg" type="image/x-icon">
	<title>eznotes</title>
</head>
<body>

    <!--Header navigation-->
    <?php include 'usersettings-header.php'; ?>
    <!--End of Header navigation-->

    <div class="usersettings-maincontainer">

    <div class="available-user-options-container">
        <div class="profile-settings-container">
            <h2>Profile settings</h2>
            <button class="profile-section"><img class="profile-section-image" src="/Note/content/assets/images/user.png"> Profile</button>
            <button class="notification-section"><img class="notification-section-image" src="/Note/content/assets/images/notification.png"> Notifications</button>
        </div>

        <div class="user-management-container">
            <h2>Management</h2>
            <button class="spaces-section"><img class="spaces-section-image" src="/Note/content/assets/images/spaces.png"> Spaces</button>
            <button class="themes-section"><img class="themes-section-image" src="/Note/content/assets/images/themes.png"> Themes</button>
        </div>

        <div class="others-container">
            <h2>Others</h2>
            <button class="extension-section"><img class="extension-section-image" src="/Note/content/assets/images/extension.png"> Extensions</button>
        </div>
    </div>

    <div class="user-details-container">
        <h2 class="profile-header">Profile</h2>
        <div class="detailsregulation-reminder">
            <img src="/Note/content/assets/images/info2.png">
            <span>Reminder: Ensure profile credentials are correct in the Account settings.</span>   
        </div>
        <form action="" method="POST" enctype="multipart/form-data">
        <div class="profile-picture-container">
        <div class="userprofile-image-circle">
        <img src="<?php echo $userImage; ?>" alt="User Image">
        </div>
        <div class="change-picture-container">
        <div class="custom-file-upload">
    <label for="selectedImageFile" class="uploadphotobtn">Upload Photo</label>
    <input type="file" name="selectedImageFile" id="selectedImageFile" class="file-input" readonly>
    </div>
        <span>At least 500 x 500px PNG or JPG file</span>
        </div>
        </div>

        <div class="users-edit-studentid-fullname-container">
            <div class="edit-studentid">
                <label>Student ID</label>
                <div class="col-md-8">
                <input type="number" class="form-control" value="<?php echo $userStudentID ?>" readonly>
                </div>
            </div>

            <div class="edit-fullname">
                <label>Fullname</label>
                <div class="col-md-8">
                <input type="text" class="form-control" name="edit-fullname" value="<?php echo $fullname; ?>" required>
                </div>
                
            </div>
        </div>

        <div class="edit-email">
                <label>Email</label>
                <div class="col-md-8">
                <input id="edit-emailinput" class="form-control" name="edit-email" type="email" value="<?php echo $email; ?>" required>
                </div>
            </div>

            <div class="editemail-message-alert" id="editemail-message-alert">
                        <p>
                         <i class="fas fa-exclamation-triangle"></i> Email already in use.
                        </p>
                </div>

        
            <div class="edit-password">
                <label>Password</label>
                <div class="col-md-8">
                <input type="password" id="passwordInput" class="form-control" name="edit-password" class="password-input" value="<?php echo $studentpassword; ?>" required>
                </div>
                <button class="show-password-button" id="showPasswordButton"><img class="password-reveal" src="/Note/content/assets/images/showpassword.png"></button>
            </div>

            <div class="editpassword-message-alert" id="editpassword-message-alert">
                        <p>
                         <i class="fas fa-exclamation-triangle"></i> Password already in use.
                        </p>
                </div>

            <div class="edit-button">
                <button id="edit-userdetails-btn" type="submit" name="edit-userdetails-btn">Save</button>
            </div>


            </form>

    </div>


    </div>

    <script src="./assets/js/revealpassword.js"></script>
    <script>
    function openImageUploader() {
        console.log("openImageUploader function called");



        // Get the existing file input from the HTML
        var fileInput = document.getElementById("selectedImageFile");

        // Trigger a click event on the file input
        fileInput.click();

        // Handle the file input change event
        fileInput.addEventListener("change", function () {
            // Handle the selected file if needed
            var selectedFile = fileInput.files[0];
            console.log("Selected File:", selectedFile);

            if (selectedFile) {
                // If you want to display a preview, you can use FileReader
                var reader = new FileReader();
                reader.onload = function (e) {
                    // Display the preview (replace 'previewImageElement' with the actual image element)
                    console.log("Preview URL:", e.target.result);
                    document.querySelector(".userprofile-image-circle img").src = e.target.result;
                };
                reader.readAsDataURL(selectedFile);
            }
        });
    }

    // Attach the function to the file input change event
    document.getElementById("selectedImageFile").addEventListener("click", openImageUploader);
</script>

<script>
    // Check for the 'refresh' parameter in the URL
    const urlParams = new URLSearchParams(window.location.search);
    const refreshParam = urlParams.get('refresh');

    // Force a hard refresh if the 'refresh' parameter is present
    if (refreshParam) {
        setTimeout(function () {
            // Use location.href to navigate to the same page without refreshing
            location.href = location.href.split('?')[0];

            // Remove the 'refresh' parameter from the URL
            urlParams.delete('refresh');
            const newUrl = window.location.pathname + '?' + urlParams.toString() + window.location.hash;
            window.history.replaceState({}, document.title, newUrl);
        }, 100); // Adjust the delay if needed
    }
</script>





</body>
</html>