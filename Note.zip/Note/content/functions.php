<?php

include 'server.php';

$userinfoCompare = array();
$usereditinfoCompare = array();
$subjectinformation = array();
$topicinformation = array();
$subjecteditinformation = array();







function registerUsers($conn, $studentID, $fullname, $email, $password) {
    // Validate and sanitize user input
    $fullname = filter_var($fullname, FILTER_SANITIZE_STRING);
    $email = filter_var($email, FILTER_SANITIZE_EMAIL);

    // Start or resume the session
    session_start();

    // Set the default location for the user image
    $userImagePath = '/Note/content/assets/images/user.png';

    // Do any other necessary validation here

    // Prepare and execute the SQL query to insert user data
    $userType = "user";
    $stmt = $conn->prepare("INSERT INTO `user` (studentID, fullname, email, password, userimage, userType) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("isssss", $studentID, $fullname, $email, $password, $userImagePath, $userType);

    if ($stmt->execute()) {
        // User registration successful
        $userData = array(
            'studentID' => $studentID,
            'fullname' => $fullname,
            'email' => $email,
            'password' => $password, // Note: Password is not hashed
            'userType' => $userType,
            'userimage' => $userImagePath
        );

        // Set the 'user' session to store user data
        $_SESSION['user'] = $userData;

        return true;
    } else {
        return false; // User registration failed
    }
}


function defaultAdminImage($conn) {
    // Check if there is an admin user with the specified default image
    $checkSql = "SELECT * FROM `user` WHERE `userType` = ? AND `userimage` = ?";
    $updateSql = "UPDATE `user` SET `userimage` = ? WHERE `userType` = ? AND `userimage` = ?";
    $userType = 'admin';  // Replace with the actual user type
    $defaultImagePath = '/Note/content/assets/images/user.png'; // Use the relative path
    $newImagePath = '/Note/content/assets/images/admin.png'; // New admin image path

    // Output the SQL query for debugging
    echo "Debug SQL: $checkSql with userType = '$userType' and userimage = '$defaultImagePath'<br>";

    $stmt = $conn->prepare($checkSql);
    $stmt->bind_param("ss", $userType, $defaultImagePath);
    $stmt->execute();
    $result = $stmt->get_result();

    // Output the result for debugging
    echo "Debug Result:<pre>";
    $resultsArray = $result->fetch_all(MYSQLI_ASSOC);
    print_r($resultsArray);
    echo "</pre>";



    // Log the results into a text file
    $logFilePath = 'D:\\XAMPP\\htdocs\\Note\\content\\assets\\logs\\changeadminimage.txt';
    file_put_contents($logFilePath, date("Y-m-d H:i:s") . " - " . "Results found:\n" . print_r($resultsArray, true) . "\n", FILE_APPEND);

    if ($result->num_rows > 0) {
        // Update userimage to the new admin image path
        $updateStmt = $conn->prepare($updateSql);
        $updateStmt->bind_param("sss", $newImagePath, $userType, $defaultImagePath);
        $updateStmt->execute();
        
        // Log success message or perform additional actions
        $logMessage = "Admin users with the specified userimage found successfully and userimage updated\n";
    } else {
        // Log failure message or perform additional actions
        $logMessage = "No admin users with the specified userimage found\n";
    }

    // Log the message into the same text file
    file_put_contents($logFilePath, date("Y-m-d H:i:s") . " - " . $logMessage, FILE_APPEND);

    // Output the message to the browser (optional)
    echo $logMessage;
}






function Login($conn, $studentID, $password) {
    
    // Prepare and execute the SQL query to retrieve user data
    $stmt = $conn->prepare("SELECT * FROM `user` WHERE `studentID` = ?");
    $stmt->bind_param("i", $studentID);  // Use "i" for integer
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        // User found, verify password
        $userData = $result->fetch_assoc();
        if ($password === $userData['password']) {
            // Password is correct, start or resume the session
            session_start();

            // Create a session and store an array of user details based on userType
            if ($userData['userType'] === 'user') {
                $_SESSION['user'] = array(
                    'studentID' => $userData['studentID'],
                    'fullname' => $userData['fullname'],
                    'email' => $userData['email'],
                    'password' => $userData['password'],
                    'userimage' => $userData['userimage'],
                    'userType' => $userData['userType']
                );

                // Redirect user to homepage.php
                header("Location: homepage.php");
                exit();
            } elseif ($userData['userType'] === 'admin') {

                // Call the function with the database connection
                defaultAdminImage($conn);
                
                $_SESSION['admin'] = array(
                    'studentID' => $userData['studentID'],
                    'fullname' => $userData['fullname'],
                    'email' => $userData['email'],
                    'password' => $userData['password'],
                    'userimage' => $userData['userimage'],
                    'userType' => $userData['userType']
                );

                // Redirect admin to admin.php (modify this based on your admin page)
                header("Location: homepage.php");
    
                exit();
            }
        }
    }

   // Login failed. Log the error.
$errorLog = fopen("assets/logs/login_error.txt", "a");
$errorMessage = date("Y-m-d H:i:s") . " - Login failed for studentID: $studentID with password: $password\n";
fwrite($errorLog, $errorMessage);
fclose($errorLog);


    header("Location: signin.php?loginerror=1");
    exit();
}




function RetrieveAllUsers($conn) {
    global $userinfoCompare; // Access the global array

    // Perform a SQL query to select all users from the "user" table
    $sql = "SELECT * FROM user";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        // Fetch user data and store it in the userinfoCompare array
        while ($row = mysqli_fetch_assoc($result)) {
            $userinfoCompare[] = $row;
        }

        // Free the result set
        mysqli_free_result($result);
    } else {
        // Handle the query error if necessary
        // For example, you can log an error message or take appropriate action
    }
}


function RetrieveAllUsersForEdit($conn){
    global $usereditinfoCompare; // Access the global array

    // Get the user ID of the user currently in session
    $currentUserID = isset($_SESSION['admin']['studentID']) ? $_SESSION['admin']['studentID'] : (isset($_SESSION['user']['studentID']) ? $_SESSION['user']['studentID'] : null);



    // Perform a SQL query to select all users from the "user" table except the current user
    $sql = "SELECT * FROM user WHERE studentID <> ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $currentUserID);

    if ($stmt->execute()) {
        $result = $stmt->get_result();
        
        if ($result) {
            // Fetch user data and store it in the userinfoCompare array
            while ($row = $result->fetch_assoc()) {
                $usereditinfoCompare[] = $row;
            }

            // Free the result set
            $result->free();
        } else {
            // Handle the query error if necessary
            // For example, you can log an error message or take appropriate action
        }
    } else {
        // Handle the query execution error if necessary
        // For example, you can log an error message or take appropriate action
    }
}






// Function to retrieve subject information
function getSubjectInformation() {
    global $conn, $subjectinformation;

    // Clear existing data in the array
    $subjectinformation = array();

    // SQL query to retrieve subject information
    $sql = "SELECT * FROM subjects";
    $result = $conn->query($sql);

    // Log file path
    $logFilePath = 'D:\\XAMPP\\htdocs\\Note\\content\\assets\\logs\\SubjectTableData.txt';

    // Open or create the log file for writing (append mode)
    $logFile = fopen($logFilePath, 'a');

    if ($result->num_rows > 0) {
        // Loop through each row and store data in the global array
        while ($row = $result->fetch_assoc()) {
            $subject_id = $row['subject_id'];
            $subject_name = $row['subject_name'];
            $subject_created = $row['subject_created'];
            $num_topics = $row['num_topics'];

            // Store data in the global array
            $subjectinformation[] = array(
                'subject_id' => $subject_id,
                'subject_name' => $subject_name,
                'subject_created' => $subject_created,
                'num_topics' => $num_topics
            );

            // Log the data to the file
            $logData = "Subject ID: $subject_id, Subject Name: $subject_name, Subject Created: $subject_created, Num Topics: $num_topics" . PHP_EOL;
            fwrite($logFile, $logData);
        }
    }

    // Close the log file
    fclose($logFile);
}


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'get_subject_info' && isset($_POST['subject_id'])) {
        $subjectId = $_POST['subject_id'];
        getSubjectInformationForEdit($conn, $subjectId);
    } else {
        // Handle other actions if needed
    }
}

if (isset($_POST['action']) && $_POST['action'] === 'get_subject_info') {
    getSubjectInformationForEdit($conn, 'your_subject_id');  // Replace 'your_subject_id' with the actual subject ID
}

function getSubjectInformationForEdit($conn, $subjectId) {
    global $subjecteditinformation;

    // Initialize variables
    $currentDateTime = date('Y-m-d H:i:s');
    $logFilePath = 'D:/XAMPP/htdocs/Note/content/assets/logs/retrievesubjectedit.txt';

    // Perform a SQL query to select the subject information
    $sql = 'SELECT * FROM subjects WHERE subject_id = ?';
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('s', $subjectId);

    if ($stmt->execute()) {
        $result = $stmt->get_result();

        if ($result) {
            // Clear existing data in the array
            $subjecteditinformation = array();

            // Open or create the log file for writing (append mode)
            $logFile = fopen($logFilePath, 'a');

            // Loop through each row and store data in the global array
            while ($row = $result->fetch_assoc()) {
                $subject_id = $row['subject_id'];
                $subject_name = $row['subject_name'];
                $subject_created = $row['subject_created'];
                $num_topics = $row['num_topics'];

                // Store data in the global array
                $subjecteditinformation[] = array(
                    'subject_id' => $subject_id,
                    'subject_name' => $subject_name,
                    'subject_created' => $subject_created,
                    'num_topics' => $num_topics
                );

                // Log the data to the file
                $logData = "Subject ID: $subject_id, Subject Name: $subject_name, Subject Created: $subject_created, Num Topics: $num_topics" . PHP_EOL;
                fwrite($logFile, $logData);
            }

            // Close the log file
            fclose($logFile);

            $result->free();
        } else {
            // Handle the query error if necessary
            $logMessage = "$currentDateTime: Query error - " . $stmt->error . "\n";
            file_put_contents($logFilePath, $logMessage, FILE_APPEND);
        }
    } else {
        // Handle the query execution error if necessary
        $logMessage = "$currentDateTime: Query execution error - " . $stmt->error . "\n";
        file_put_contents($logFilePath, $logMessage, FILE_APPEND);
    }

    $stmt->close();

    // Check if $subjecteditinformation is set
    if (isset($subjecteditinformation)) {
        // Encode the subject information as JSON
        $jsonResponse = json_encode($subjecteditinformation);
    
        // Echo the JSON response
        echo $jsonResponse;
    
        // Log the request and results to a file
        $logMessage = "$currentDateTime: Request for subject ID $subjectId - " . $jsonResponse . "\n";
        file_put_contents($logFilePath, $logMessage, FILE_APPEND);

        exit();
    } else {
        // Handle the case where $subjecteditinformation is not set
        $logMessage = "$currentDateTime: Subject information not found for ID $subjectId\n";
        file_put_contents($logFilePath, $logMessage, FILE_APPEND);
    }
}


function editaccount($conn) {
    // Assuming the form is submitted
    if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["edit-userdetails-btn"])) {
        // Retrieve the input values
        $fullname = $_POST["edit-fullname"];
        $email = $_POST["edit-email"];
        $password = $_POST["edit-password"];

        // Get the user ID from the session or set it to null if not found
        $adminID = $_SESSION['admin']['studentID'] ?? null;
        $userID = $_SESSION['user']['studentID'] ?? null;

        $userType = null; // Variable to store the current user type

        if ($adminID) {
            $userType = 'admin';
            $userID = $adminID;
        } elseif ($userID) {
            $userType = 'user';
        } else {
            // Handle the case where the user ID is not available
            echo "Error: User ID not found.";
            return;
        }

        // Check if the selectedImageFile input is set in the form
        if (isset($_FILES["selectedImageFile"])) {
            // Generate a filename based on the user's student ID
            $filename = $userID . ".png"; // You can change the extension based on the actual image type

            // Update the selectedImage value with the file path
            $selectedImage = "/Note/content/assets/images/userprofilepicture/" . $filename;

            // Log the variables
            $logContent = "fullname: $fullname, email: $email, password: $password, selectedImage: $selectedImage, userID: $userID";
            file_put_contents($_SERVER["DOCUMENT_ROOT"] . "/Note/content/assets/logs/editprofileresult.txt", $logContent);

            // Move the uploaded image to the destination folder with the desired filename
            $destination = $_SERVER["DOCUMENT_ROOT"] . $selectedImage;

            // Log the destination path
            $logDestination = "Destination: $destination";
            file_put_contents($_SERVER["DOCUMENT_ROOT"] . "/Note/content/assets/logs/editprofileresult.txt", $logDestination, FILE_APPEND);

            move_uploaded_file($_FILES["selectedImageFile"]["tmp_name"], $destination);

            // Update the user's profile image in the database
            $sql = "UPDATE user SET fullname=?, email=?, password=?, userimage=? WHERE studentID=?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssssi", $fullname, $email, $password, $selectedImage, $userID);

            if ($stmt->execute()) {
                // Update the session with the new user details
                $_SESSION[$userType]['fullname'] = $fullname;
                $_SESSION[$userType]['email'] = $email;
                $_SESSION[$userType]['password'] = $password;
                $_SESSION[$userType]['userimage'] = $selectedImage;

                // Echo a script to trigger a delayed refresh (3 seconds) on the client side
                header("Location: usersettings.php?refresh=" . time());
                exit(); // Ensure that no more output is sent
            } else {
                // Handle the update failure
                echo "Error updating account details: " . $stmt->error;
            }

            // Close the database connection
            $stmt->close();
        } else {
            // Update other user details in the database if no profile image is uploaded
            $sql = "UPDATE user SET fullname=?, email=?, password=? WHERE studentID=?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sssi", $fullname, $email, $password, $userID);

            if ($stmt->execute()) {
                // Update the session with the new user details
                $_SESSION[$userType]['fullname'] = $fullname;
                $_SESSION[$userType]['email'] = $email;
                $_SESSION[$userType]['password'] = $password;

                // Echo a script to trigger a delayed refresh (3 seconds) on the client side
                header("Location: usersettings.php?refresh=" . time());
                exit(); // Ensure that no more output is sent
            } else {
                // Handle the update failure
                echo "Error updating account details: " . $stmt->error;
            }

            // Close the database connection
            $stmt->close();
        }

        $conn->close();
    }
}



function addSubject($conn, $subject_id, $subject_name) {
    // Escape user inputs to prevent SQL injection
    $subject_id = mysqli_real_escape_string($conn, $subject_id);
    $subject_name = mysqli_real_escape_string($conn, $subject_name);

    // Check if the subject ID already exists
    $checkQuery = "SELECT * FROM subjects WHERE subject_id = '$subject_id'";
    $checkResult = $conn->query($checkQuery);

    if ($checkResult->num_rows > 0) {
        // Subject ID already exists
        $conn->close(); // Close the database connection
        return false;
    }

    // Insert the new subject into the subjects table
    $insertQuery = "INSERT INTO subjects (subject_id, subject_name) VALUES ('$subject_id', '$subject_name')";
    $insertResult = $conn->query($insertQuery);

    $conn->close(); // Close the database connection

    if ($insertResult) {
        // Redirect to dashboard.php upon successful insertion
        header("Location: dashboard.php");
        exit(); // Ensure that no further code is executed after the redirect
    }

    return $insertResult;
}




function editSubject($conn, $edit_subject_id, $edit_subject_name)
{
    // Escape user inputs to prevent SQL injection
    $edit_subject_id = mysqli_real_escape_string($conn, $edit_subject_id);
    $edit_subject_name = mysqli_real_escape_string($conn, $edit_subject_name);

    // Check if the subject ID exists
    $checkQuery = "SELECT * FROM subjects WHERE subject_id = '$edit_subject_id'";
    $checkResult = $conn->query($checkQuery);

    if ($checkResult->num_rows === 0) {
        // Subject ID does not exist
        echo "Subject ID does not exist!";
        return false;
    }

    // Update the subject in the subjects table
    $updateQuery = "UPDATE subjects SET subject_name = '$edit_subject_name' WHERE subject_id = '$edit_subject_id'";
    $updateResult = $conn->query($updateQuery);

    if ($updateResult) {
        // Redirect to dashboard.php upon successful update
        header("Location: dashboard.php");
        exit(); // Ensure that no further code is executed after the redirect
    } else {
        // Update failed
        echo "Error updating subject: " . $conn->error;

        // Create a text file named faileditsubject.txt in the specified path
        $logFilePath = 'D:/XAMPP/htdocs/Note/content/assets/logs/faileditsubject.txt';
        $logContent = "Subject update failed for ID: $edit_subject_id";

        file_put_contents($logFilePath, $logContent, FILE_APPEND | LOCK_EX);
    }

    return $updateResult;
}





function deleteSubject($conn, $subjectId) {
    try {
        // Temporarily disable foreign key checks
        $conn->query("SET foreign_key_checks = 0");

        // Start a transaction
        $conn->begin_transaction();

        // Manually delete associated records in the child tables
        $stmtTopics = $conn->prepare("DELETE FROM topics WHERE subject_id = ?");
        $stmtTopics->bind_param('s', $subjectId);
        $stmtTopics->execute();

        $stmtFiles = $conn->prepare("DELETE FROM files WHERE topic_id IN (SELECT topic_id FROM topics WHERE subject_id = ?)");
        $stmtFiles->bind_param('s', $subjectId);
        $stmtFiles->execute();

        // Then, delete the record in the subjects table
        $stmtSubjects = $conn->prepare("DELETE FROM subjects WHERE subject_id = ?");
        $stmtSubjects->bind_param('s', $subjectId);
        $stmtSubjects->execute();

        // Commit the transaction
        $conn->commit();

        // Re-enable foreign key checks
        $conn->query("SET foreign_key_checks = 1");

        // Check if the deletion was successful
        if ($stmtSubjects->affected_rows > 0) {
            // Deletion successful, redirect to dashboard.php
            header('Location: dashboard.php');
            exit();
        } else {
            // Deletion failed
            error_log("Error deleting subject: No rows affected");
            return false;
        }
    } catch (Exception $e) {
        // An error occurred, rollback the transaction
        $conn->rollback();
        // Re-enable foreign key checks
        $conn->query("SET foreign_key_checks = 1");
        // Log the error to a file
        error_log("Error deleting subject: " . $e->getMessage(), 3, __DIR__ . '/assets/logs/faileddeletesubject.txt');
        // Return false to indicate deletion failure
        return false;
    }
}


if (isset($_POST['action']) && $_POST['action'] === 'getSelectedTopic') {
    $selectedSubjectId = $_POST['selectedSubjectId'];
    
    // Include your database connection and function definitions

    // Call the getSelectedTopic function
    getSelectedTopic($conn, $selectedSubjectId);


    exit();
}



function getSelectedTopic($conn, $selectedSubjectId) {
    global $topicinformation;

    // Clear the existing data in $topicinformation
    $topicinformation = array();

    // SQL query to retrieve topics for the selected subject_id
    $sql = "SELECT * FROM topics WHERE subject_id = '$selectedSubjectId'";

    // Execute the query
    $result = $conn->query($sql);

    // Check for query execution errors
    if (!$result) {
        die("Error: " . $conn->error);
    }

    // Fetch topics and store them in $topicinformation
    while ($row = $result->fetch_assoc()) {
        $topicinformation[] = $row;
    }

    // Close the result set
    $result->close();

    // Send the topic information as JSON to the client
    echo json_encode($topicinformation);

}



function addNewTopic($conn) {
    // Check if the required parameters are set
    if (isset($_POST['selectedSubjectId'], $_POST['topicName'])) {
        // Sanitize and validate inputs
        $selectedSubjectId = mysqli_real_escape_string($conn, $_POST['selectedSubjectId']);
        $topicName = mysqli_real_escape_string($conn, $_POST['topicName']);

        // Insert the new topic into the database
        $query = "INSERT INTO topics (topic_name, subject_id) VALUES ('$topicName', '$selectedSubjectId')";
        $result = mysqli_query($conn, $query);

        if ($result) {
            // Retrieve the details of the newly added topic
            $topicId = mysqli_insert_id($conn); // Get the last inserted ID
            $topicinformation = [
                'status' => 'success',
                'topicId' => $topicId,
                'topicName' => $topicName,
                'message' => 'Topic added successfully'
            ];

            // Send the topic information as JSON to the client
            echo json_encode($topicinformation);
        } else {
            // Return an error message or any other response you want
            echo json_encode(['status' => 'error', 'message' => 'Error adding topic']);
        }
    } else {
        // Return an error message if required parameters are not set
        echo json_encode(['status' => 'error', 'message' => 'Missing parameters']);
    }
}


function RenameTopic($conn, $topicId, $newTopicName) {
    // Check for a valid connection
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Sanitize inputs to prevent SQL injection
    $topicId = mysqli_real_escape_string($conn, $topicId);
    $newTopicName = mysqli_real_escape_string($conn, $newTopicName);

    // Update the topic name in the database
    $sql = "UPDATE topics SET topic_name = '$newTopicName' WHERE topic_id = $topicId";

    if (mysqli_query($conn, $sql)) {
        echo "Topic updated successfully";
    } else {
        echo "Error updating topic: " . mysqli_error($conn);
    }

    // Close the database connection
    mysqli_close($conn);
}



function RenameFile($conn, $fileId, $newFileName) {
    // Prepare and execute the SQL query to update the file name
    $stmt = $conn->prepare("UPDATE files SET file_name = ? WHERE file_id = ?");
    $stmt->bind_param("si", $newFileName, $fileId);

    if ($stmt->execute()) {
        // The file name has been successfully updated
        echo "File name updated successfully.";
    } else {
        // An error occurred during the update
        echo "Error updating file name: " . $stmt->error;
    }

    // Close the statement
    $stmt->close();
}



function deleteTopic($conn) {
    // Check if the required parameters are set
    if (isset($_POST['topicId'])) {
        // Sanitize and validate input
        $topicId = mysqli_real_escape_string($conn, $_POST['topicId']);

        // Delete the topic from the database
        $query = "DELETE FROM topics WHERE topic_id = '$topicId'";
        $result = mysqli_query($conn, $query);

        if ($result) {
            // Return a success message or any other response you want
            echo json_encode(['status' => 'success', 'message' => 'Topic deleted successfully']);
        } else {
            // Return an error message or any other response you want
            echo json_encode(['status' => 'error', 'message' => 'Error deleting topic']);
        }
    } else {
        // Return an error message if required parameters are not set
        echo json_encode(['status' => 'error', 'message' => 'Missing parameters']);
    }
}


function deleteFile($conn, $fileId) {
    // Prepare and execute the SQL statement to delete the file
    $stmt = $conn->prepare("DELETE FROM files WHERE file_id = ?");
    $stmt->bind_param("i", $fileId);

    if ($stmt->execute()) {
        // File deleted successfully
        echo json_encode(array('result' => 'success', 'message' => 'File deleted successfully'));
    } else {
        // Error occurred while deleting the file
        echo json_encode(array('result' => 'error', 'message' => 'Error: ' . $stmt->error));
    }

    // Close the statement
    $stmt->close();
}


function displayTopicFiles($conn, $topicId) {
    // Sanitize and validate input
    $topicId = mysqli_real_escape_string($conn, $topicId);

    // Initialize an array to store file information
    $filesArray = [];

    // Fetch files and subject_id for the given topic_id
    $query = "SELECT f.file_id, f.file_name, f.file_path, t.subject_id
              FROM files f
              JOIN topics t ON f.topic_id = t.topic_id
              WHERE f.topic_id = '$topicId'";
    $result = mysqli_query($conn, $query);

    // Check if the query was successful
    if ($result) {
        // Loop through the files and add them to the array
        while ($row = mysqli_fetch_assoc($result)) {
            $fileId = $row['file_id'];
            $fileName = $row['file_name'];
            $filePath = $row['file_path'];
            $subjectId = $row['subject_id'];

            // Add file information to the array
            $filesArray[] = [
                'fileId' => $fileId,
                'fileName' => $fileName,
                'filePath' => $filePath,
                'subjectId' => $subjectId,
                'topicId' => $topicId  // Add the topic_id to the array
            ];
        }
    } else {
        // Query execution failed
        $filesArray['error'] = "Error retrieving files: " . mysqli_error($conn);
    }

    // Fetch subject_id only if no files were found
    $querySubject = "SELECT subject_id FROM topics WHERE topic_id = '$topicId'";
    $resultSubject = mysqli_query($conn, $querySubject);

    $subjectId = null;

    if ($rowSubject = mysqli_fetch_assoc($resultSubject)) {
        $subjectId = $rowSubject['subject_id'];
    }

    // Create emptyFilesArray with only the subjectId and topicId
    $emptyFilesArray = [
        'subjectId' => $subjectId,
        'topicId' => $topicId  // Add the topic_id to the array
    ];

    // Echo the result as JSON, even if it's an empty array
    echo json_encode(!empty($filesArray) ? $filesArray : $emptyFilesArray);
}





function addNewFile($conn, $topicId, $filename) {
    $topicId = $_POST['topicId'];
    


    // Check if the required parameters are set
    if (!isset($topicId) || !isset($filename)) {
        echo json_encode(['error' => "Error: Missing parameters for addNewFile"]);
        return;
    }

    $subjectId = null;

    // Get the subject_id for the given topic_id
    $querySubject = "SELECT subject_id FROM topics WHERE topic_id = ?";
    $stmtSubject = $conn->prepare($querySubject);
    $stmtSubject->bind_param("i", $topicId);
    $stmtSubject->execute();
    $stmtSubject->bind_result($subjectId);

    // Fetch the subject_id
    if ($stmtSubject->fetch()) {
        // Define the base directory for files
        $baseDirectory = "D:/XAMPP/htdocs/Note/content/assets/files";

        // Create or use the subject folder
        $subjectFolder = "{$baseDirectory}/{$subjectId}";
        if (!is_dir($subjectFolder)) {
            if (!mkdir($subjectFolder, 0755, true)) {
                $error = error_get_last();
                $response = [
                    'error' => "Error creating subject folder: {$subjectFolder}",
                    'mkdir_error' => $error,
                    'subjectFolder' => $subjectFolder,
                    'baseDirectory' => $baseDirectory,
                    'subjectId' => $subjectId,
                    'is_dir_subjectFolder' => is_dir($subjectFolder),
                    'is_writable_baseDirectory' => is_writable($baseDirectory),
                ];
                echo json_encode($response);

                // Log the response to a text file
                error_log(json_encode($response, JSON_PRETTY_PRINT));

                return;
            }
        }

        // Create or use the topic folder
        $topicFolder = "{$subjectFolder}/{$topicId}";
        if (!is_dir($topicFolder)) {
            if (!mkdir($topicFolder, 0755, true)) {
                $error = error_get_last();
                $response = [
                    'error' => "Error creating topic folder: {$topicFolder}",
                    'mkdir_error' => $error,
                    'topicFolder' => $topicFolder,
                    'subjectFolder' => $subjectFolder,
                    'is_dir_topicFolder' => is_dir($topicFolder),
                    'is_writable_subjectFolder' => is_writable($subjectFolder),
                ];
                echo json_encode($response);

                // Log the response to a text file
                error_log(json_encode($response, JSON_PRETTY_PRINT));

                return;
            }
        }
        // Define the file path relative to the server root
        $filePath = "/Note/content/assets/files/{$subjectId}/{$topicId}/{$filename}";

        // Move the uploaded file to the final destination
        if (move_uploaded_file($_FILES['file']['tmp_name'], $_SERVER['DOCUMENT_ROOT'] . $filePath)) {
            // File moved successfully

            // Close the statement for subject_id
            $stmtSubject->close();

            // SQL query to insert a new file into the 'files' table
            $sql = "INSERT INTO files (file_name, topic_id, file_path) VALUES (?, ?, ?)";

            // Use prepared statements to prevent SQL injection
            $stmt = $conn->prepare($sql);

            // Bind parameters
            $stmt->bind_param("sis", $filename, $topicId, $filePath);

            // Initialize an array to store the information of the newly added file
            $newAddedFile = [];

            // Execute the query
            if ($stmt->execute()) {
                // Insert successful
                $newAddedFile = [
                    'fileId' => $stmt->insert_id,
                    'fileName' => $filename,
                    'filePath' => $filePath,
                    'topicId' => $topicId
                ];

                // Echo the result as JSON
                $result = json_encode($newAddedFile);

                // Log the result into a text file
                $logDirectory = 'D:/XAMPP/htdocs/Note/content/assets/logs';
                $logFilePath = "{$logDirectory}/addNewFiles.txt";

                // Ensure the log directory exists
                if (!is_dir($logDirectory)) {
                    mkdir($logDirectory, 0755, true);
                }

                // Log the result to the text file
                file_put_contents($logFilePath, $result . PHP_EOL, FILE_APPEND);

                // Echo the result as JSON
                echo $result;
            } else {
                // Insert failed
                echo json_encode(['error' => "Error adding new file: " . $stmt->error]);
            }

            // Close the statement
            $stmt->close();
        } else {
            // File move failed
            echo json_encode(['error' => "Error moving uploaded file"]);
        }
    } else {
        // Subject not found for the given topic_id
        echo json_encode(['error' => "Error: Subject not found for topic_id {$topicId}"]);
        $stmtSubject->close();  // Close the statement for subject_id
    }
}


// Check if the action parameter is set and call the corresponding function
if (isset($_POST['action'])) {
    $action = $_POST['action'];

    switch ($action) {
        case 'addNewTopic':
            addNewTopic($conn);
            break;
        case 'RenameTopic':
            // Check if the required parameters are set
            if (isset($_POST['topicId']) && isset($_POST['newTopicName'])) {
                // Call the RenameTopic function
                RenameTopic($conn, $_POST['topicId'], $_POST['newTopicName']);
            } else {
                echo "Error: Missing parameters for RenameTopic";
            }
            break;
        case 'deleteTopic':
            deleteTopic($conn);
            break;
        case 'retrieveTopicFiles':
            // Check if the required parameters are set
            if (isset($_POST['topicId'])) {
                // Call the retrieveTopicFiles function
                displayTopicFiles($conn, $_POST['topicId']);
            } else {
                echo "Error: Missing parameters for retrieveTopicFiles";
            }
            break;
        case 'RenameFile':
            // Check if the required parameters are set
            if (isset($_POST['fileId']) && isset($_POST['newFileName'])) {
                // Call the RenameFile function
                RenameFile($conn, $_POST['fileId'], $_POST['newFileName']);
            } else {
                echo "Error: Missing parameters for RenameFile";
            }
            break;
        case 'deleteFile':
            // Check if the required parameters are set
            if (isset($_POST['fileId'])) {
                // Call the deleteFile function
                deleteFile($conn, $_POST['fileId']);
            } else {
                echo "Error: Missing parameters for deleteFile";
            }
            break;
            case 'addNewFile':
                // Call the addNewFile function
                addNewFile($conn, $_POST['topicId'], $_POST['filename']);
                break;
            
        // Add more cases for other actions if needed
    }
}




function getCommentsBySubject($conn, $subject_id) {
    $commentinfo = array();

    // Select comments with user details based on subject_id
    $sql = "SELECT c.comment_id, c.comment_content, c.comment_date, c.is_edited, c.studentID, c.subject_id, 
    CONCAT(SUBSTRING_INDEX(u.fullname, ' ', 2)) AS fullname, u.userimage, u.userType
FROM `comment` c
JOIN `user` u ON c.studentID = u.studentID
WHERE c.subject_id = ?";

    
    // Use prepared statement to prevent SQL injection
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $subject_id);
    $stmt->execute();

    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Fetch comments and store in $commentinfo array
        while ($row = $result->fetch_assoc()) {
            $commentinfo[] = $row;
        }

        // Echo the JSON-encoded array
        echo json_encode($commentinfo);
    } else {
         // Echo an empty array or a message indicating no comments
    $response = array(
        'comments' => array(),
        'subject_id' => $subject_id
    );
    echo json_encode($response);
    }

    // Close the prepared statement
    $stmt->close();
}



    // Check if the action and subject_id are set
    if (isset($_POST['action']) && isset($_POST['subject_id'])) {
        $action = $_POST['action'];
        $subject_id = $_POST['subject_id'];

        // Check the action and call the appropriate function
        switch ($action) {
            case 'getCommentsBySubject':
                getCommentsBySubject($conn, $subject_id);
                break;

            // Add more cases for other actions if needed

            default:
                echo json_encode(array('error' => 'Invalid action.'));
                break;
        }
    }



    function editComment($conn, $comment_id, $edited_comment_content) {
        // Validate and sanitize input if needed
    
        // Prepare and execute the update query
        $sql = "UPDATE comment SET comment_content = ?, is_edited = 'edited' WHERE comment_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("si", htmlspecialchars_decode($edited_comment_content), $comment_id);
    
        if ($stmt->execute()) {
            // If the query was successful, send a success response
            $response = array('status' => 'success', 'message' => 'Comment edited successfully');
            echo json_encode($response);
        } else {
            // If there was an error with the query, send an error response
            $response = array('status' => 'error', 'message' => 'Error editing comment');
            echo json_encode($response);
        }
    
        // Close the statement
        $stmt->close();
    }

// Check if the action is set in the POST request
if (isset($_POST['action'])) {
    $action = $_POST['action'];

    // Handle the editComment action
    if ($action === 'editComment') {
        // Check if the required parameters are set
            // Get and sanitize the input data
            $comment_id = (int) $_POST['commentId'];
            $edited_comment_content = htmlspecialchars($_POST['edited_comment_content']);

            // Call the editComment function with the database connection and input data
            editComment($conn, $comment_id, $edited_comment_content);
        
    }
}



function deleteComment($conn) {
    // Check if commentId is set in the POST data
    if (isset($_POST['commentId'])) {
        // Get the commentId from the POST data
        $commentId = $_POST['commentId'];


        
        // Perform the SQL query to delete the comment
        $sql = "DELETE FROM comment WHERE comment_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('i', $commentId);

        // Check if the query execution was successful
        if ($stmt->execute()) {
            // If the deletion was successful, send a success response
            $response = array('status' => 'success', 'message' => 'Comment deleted successfully');
            echo json_encode($response);
            exit;
        } else {
            // If there was an error during deletion, send an error response
            $response = array('status' => 'error', 'message' => 'Error deleting comment');
            echo json_encode($response);
            exit;
        }
    }

    // If commentId is not set, send an error response
    $response = array('status' => 'error', 'message' => 'Invalid request');
    echo json_encode($response);
    exit;
}


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'deleteComment') {
        deleteComment($conn);
    }
    // Add other actions if needed
}


function addComment($conn, $comment_content, $studentID, $subject_id) {
    // Validate and sanitize input if needed

    // Prepare and execute the insert query
    $sql = "INSERT INTO comment (comment_content, studentID, subject_id) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sis", $comment_content, $studentID, $subject_id);

    if ($stmt->execute()) {
        // If the query was successful, fetch the details of the added comment
        $comment_id = $stmt->insert_id;
        
        // Fetch comment details with user information
        $selectSql = "SELECT c.comment_id, c.comment_content, c.comment_date, c.is_edited, c.studentID, c.subject_id, 
                          CONCAT(SUBSTRING_INDEX(u.fullname, ' ', 1), ' ', SUBSTRING_INDEX(SUBSTRING_INDEX(u.fullname, ' ', 2), ' ', -1)) AS fullname,
                          u.userimage, u.userType
                   FROM comment c
                   JOIN user u ON c.studentID = u.studentID
                   WHERE c.comment_id = ?";
        $selectStmt = $conn->prepare($selectSql);
        $selectStmt->bind_param("i", $comment_id);
        $selectStmt->execute();

        $result = $selectStmt->get_result();

        if ($result->num_rows > 0) {
            $comment_details = $result->fetch_assoc();
            
            // Send a success response with the comment details
            $response = $comment_details;
            echo json_encode($response);
        } else {
            // If there was an error getting comment details, send an error response
            $response = array('status' => 'error', 'message' => 'Error adding comment');
            echo json_encode($response);
        }

        // Close the statement
        $selectStmt->close();
    } else {
        // If there was an error with the query, send an error response
        $response = array('status' => 'error', 'message' => 'Error adding comment');
        echo json_encode($response);
    }

    // Close the statement
    $stmt->close();
}


// Check if the action is set in the request
if (isset($_POST['action']) && $_POST['action'] === 'addComment') {
    // Check if other required data is set in the request
    if (isset($_POST['commentContent'], $_POST['studentID'], $_POST['subjectID'])) {
        // Get the data from the request
        $comment_content = $_POST['commentContent'];
        $studentID = $_POST['studentID'];
        $subject_id = $_POST['subjectID'];

        // Call the addComment function with the retrieved data
        addComment($conn, $comment_content, $studentID, $subject_id);
    } else {
        // If required data is missing, send an error response
        $response = array('status' => 'error', 'message' => 'Missing data for adding comment');
        echo json_encode($response);
    }
}

?>