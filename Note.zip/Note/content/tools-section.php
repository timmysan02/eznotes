
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="./assets/css/styles.css" />
    <link rel="stylesheet" href="./assets/css/style.css" />
	<title>Note</title>
</head>
<body>

<div class="dashboard-main-section">
        <div class="dashboard-header">
            <h2>Catalog</h2>
        </div>
        
        <div class="dashboard-tools-section">
            <div class="dashboard-searchbar">
            <input type="text" placeholder="Search">
            </div>

            <div class="dashboard-spaces">
            <button>
                <span class="spaces-header">Spaces</span>
                <div class="spaces-type">
                    <span>All</span>
                </div>
                <img src="/Note/content/assets/images/down-arrow.png">
            </button>
            </div>

            <div class="dashboard-types">
                <button>
                <span>Types</span>
                <img src="/Note/content/assets/images/down-arrow.png">
                </button>
              
            </div>

            <div class="dashboard-filter">
                <button>
                    <img src="/Note/content/assets/images/filter.png">
                    <span>All filters</span>
                </button>
            </div>

            <div class="dashboard-folder-arrangement">
                <button>
                    <span>Recently used</span>
                    <img src="/Note/content/assets/images/down-arrow.png">
                </button>
            </div>

            <div class="folder-view-hr">
                <hr>
            </div>

            <div class="folder-view">
                <button style="background-color: #e5e5e5;">
                    <img src="/Note/content/assets/images/list-view.png">
                </button>

                <button>
                    <img src="/Note/content/assets/images/tile-view.png">
                </button>
            </div>
        </div>
    </div>
    
    
</body>
</html>
