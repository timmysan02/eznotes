<?php include 'functions.php';?>
<?php include 'server.php';?>
<?php RetrieveAllUsers($conn); ?>


<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["signup"])) {
    $studentID = $_POST["studentid"];
    $fullname = $_POST["fullname"];
    $email = $_POST["email"];
    $password = $_POST["password"];

    if (registerUsers($conn, $studentID, $fullname, $email, $password)) {
        // Registration successful
        // Redirect to homepage.php or any other appropriate action
        header("Location: homepage.php");
        exit();
    } else {
        // Registration failed, you can display an error message
        $error_message = "Registration failed. Please try again.";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <link rel="stylesheet" href="./assets/css/styles.css" />
    <link rel="stylesheet" href="./assets/css/style.css" />
	<link rel="icon" href="/Note/content/assets/images/tablogo.jpg" type="image/x-icon">
	<title>eznotes</title>
</head>
<body style="display: flex;">
<div class="form-container">
        <div class="register-container">
            <div class="row">
            <div class="col-md-6 offset-md-3">
                <form autocomplete="off" action="" method="POST">

                <div class="register-logo-header">
                    <a href="homepage.php">
                    <img src="/Note/content/assets/images/mainlogo.png">
                    </a>
        
                </div>

                <h1 class="register-header">Sign Up</h1>

                <div class="studentid-email">
                    <div class="form-group studentid">
                        <label for="studentID" class="col-md-4 col-form-label">Student ID</label>
                        <div class="col-md-8">
                            <input id="studentidInput" class="form-control register-student-id" name="studentid" required>
                        </div>
                    </div>

                    <div class="form-group email">
                    <label for="studentID" class="col-md-4 col-form-label">Email</label>
                        <div class="col-md-8">
                            <input id="emailInput" type="email" class="form-control register-student-id" name="email" required>
                        </div>
                    </div>     
                </div>
                <div class="alert-for-staffid-email-container">
                <div class="staffid-message-alert" id="staffid-message-alert">
                        <p>
                         <i  class="fas fa-exclamation-triangle"></i> Student ID already in use.
                        </p>
                </div>

                <div class="email-message-alert" id="email-message-alert">
                        <p>
                         <i class="fas fa-exclamation-triangle"></i> Email already in use.
                        </p>
                </div>


                </div>

                <div class="form-group fullname">
                    <label for="fullname" class="col-md-4 col-form-label">Fullname</label>
                        <div class="col-md-8">
                            <input class="form-control register-fullname" name="fullname">
                        </div>
                    </div>

                    <div class="form-group register-psword-container">
                        <label for="password" class="col-md-4 col-form-label">Password</label>
                        <div class="col-md-8">
                            <input id="passwordInput" type="password" class="form-control" name="password"  required>
                        </div>
                    </div>

                    <div class="password-message-alert" id="password-message-alert">
                        <p>
                         <i class="fas fa-exclamation-triangle"></i> Password already in use.
                        </p>
                    </div>

                    <div class="form-group register-btn-container">
                        <button class="btn btn-primary" id="signup-button" name="signup">Register</button>
                    </div>

                    

                    <div class="another-option2">
                    <hr>
                    <span class="label-another-option">OR</span>
                    <hr>

                    <span class="redirect-signin">Already have an account? <a href="signin.php" class="signup-link">Sign In</a></span>


                    </div>

                    

                </form>
            </div>
            </div>
            
        </div>
        


    </div>

    <div class="image-container">
    <img src="/Note/content/assets/images/takingnotes.jpg" alt="Taking Notes Image">
    </div>

    <script>
        document.addEventListener("DOMContentLoaded", function() {
            // Mocking the userinfoCompare array for demonstration purposes
            var userinfoCompare = <?php echo json_encode($userinfoCompare); ?>;
            
            function RegistrationValidationProcess() {
                var inputStudentID = document.getElementById("studentidInput").value;
                var inputEmail = document.getElementById("emailInput").value;
                var inputPassword = document.getElementById("passwordInput").value;

                // Log the values filled by the user
                console.log("Input Student ID:", inputStudentID);
                console.log("Input Email:", inputEmail);
                console.log("Input Password:", inputPassword);

                // Log the values stored in userinfoCompare
                console.log("UserinfoCompare:", userinfoCompare);

                // Initialize flags for found matches
                var isStudentIDExist = false;
                var isEmailExist = false;
                var isPasswordExist = false;

                // Loop through the userinfoCompare array
                for (var i = 0; i < userinfoCompare.length; i++) {
                    var user = userinfoCompare[i];

                    if (user.studentID === inputStudentID) {
                        isStudentIDExist = true;
                        break;
                    }
                    
                    if (user.email === inputEmail) {
                        isEmailExist = true;
                        break;
                    }

                    if (user.password === inputPassword) {
                        isPasswordExist = true;
                        break;
                    }
                }

                // Log the results to the console
                console.log("isStudentIDExist:", isStudentIDExist);
                console.log("isEmailExist:", isEmailExist);
                console.log("isPasswordExist:", isPasswordExist);

                // Set visibility and style based on the result of the comparison for Email
                document.getElementById("staffid-message-alert").style.visibility = isStudentIDExist ? "visible" : "hidden";
                document.getElementById("studentidInput").style.borderColor = isStudentIDExist ? "red" : "";
                document.getElementById("emailInput").style.borderColor = isEmailExist ? "red" : "";
                document.getElementById("email-message-alert").style.visibility = isEmailExist ? "visible" : "hidden";
                

                // Set visibility and style based on the result of the comparison for Password
                document.getElementById("password-message-alert").style.visibility = isPasswordExist ? "visible" : "hidden";
                document.getElementById("passwordInput").style.borderColor = isPasswordExist ? "red" : "";
                
                // Disable the "Sign Up" button if any matches are found
                document.getElementById("signup-button").disabled = isEmailExist || isPasswordExist || isStudentIDExist;
            }

            // Attach the RegistrationValidationProcess function to the input events
            document.getElementById("studentidInput").addEventListener("input", RegistrationValidationProcess);
            document.getElementById("emailInput").addEventListener("input", RegistrationValidationProcess);
            document.getElementById("passwordInput").addEventListener("input", RegistrationValidationProcess);

            // Run the RegistrationValidationProcess function initially
            RegistrationValidationProcess();
        });
    </script>


    




</body>
</html>