<?php include 'server.php';?>
<?php include 'functions.php';?>
<?php
// Check for form submission
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["login_studentid"]) && isset($_POST["login_password"])) {
    // Get form data
    $studentID = $_POST["login_studentid"];
    $password = $_POST["login_password"];

    // Validate and sanitize user input
    $studentID = filter_var($studentID, FILTER_VALIDATE_INT);
    $password = filter_var($password, FILTER_SANITIZE_STRING);

    // Call the Login function
    Login($conn, $studentID, $password);
}

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="./assets/css/styles.css" />
    <link rel="stylesheet" href="./assets/css/style.css" />
	<link rel="icon" href="/Note/content/assets/images/tablogo.jpg" type="image/x-icon">
	<title>eznotes</title>
</head>
<body style="display: flex;">

<div class="form-container">
        <div class="login-container">
            <div class="row">
            <div class="col-md-6 offset-md-3">
                <form  action="" method="POST">

                <div class="login-logo-header">
                    <a href="homepage.php">
                    <img src="/Note/content/assets/images/mainlogo.png">
                    </a>
                   
                </div>

                <h1 class="login-header">Log In</h1>

                <div class="loginfail-message-alert" id="loginfail-message-alert">
                        <p>
                         <i  class="fas fa-exclamation-triangle"></i> Incorrect studentID or password.
                        </p>
                </div>

                    <div class="form-group-login-student-id">
                        <label for="studentID" class="col-md-4 col-form-label">Student ID</label>
                        <div class="col-md-8">
                            <input class="form-control" name="login_studentid" required>
                        </div>
                    </div>

                    <div class="form-group login-psword-container">
                        <label for="studentID" class="col-md-4 col-form-label">Password</label>
                        <div class="col-md-8">
                            <input class="form-control" name="login_password" type="password" required>
                        </div>
                    </div>

                    <div class="form-group login-btn-container">
                        <button class="btn btn-primary" name="login"> Login</button>
                    </div>

                    <div class="another-option">
                    <hr>
                    <span class="label-another-option">OR</span>
                    <hr>

                    <span class="redirect-signup">Not a member yet? <a href="signup.php" class="signup-link">Sign Up</a></span>


                    </div>

                    

                </form>
            </div>
            </div>
            
        </div>
        


    </div>

    <div class="image-container">
    <img src="/Note/content/assets/images/takingnotes.jpg" alt="Taking Notes Image">
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        var urlParams = new URLSearchParams(window.location.search);
        var loginError = urlParams.get('loginerror');

        if (loginError === '1') {
            var alertDiv = document.getElementById('loginfail-message-alert');
            alertDiv.style.visibility = 'visible';
            
            // Clear the loginerror parameter from the URL
            var urlWithoutLoginError = window.location.pathname;
            history.replaceState(null, null, urlWithoutLoginError);

            setTimeout(function() {
                alertDiv.style.visibility = 'hidden';
            }, 5000); // 5000 milliseconds = 5 seconds
        }
    });
</script>

    




</body>
</html>