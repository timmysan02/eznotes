<?php
function logout() {
    // Start or resume the session
    session_start();

    // Unset all session variables
    $_SESSION = array();

    // Destroy the session
    session_destroy();

    // Redirect to homepage.php
    header("Location: homepage.php");
    exit();
}

// Call the logout function
logout();
?>
