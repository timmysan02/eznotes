<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="icon" href="/Note/content/assets/images/tablogo.jpg" type="image/x-icon">
	<title>eznotes</title>
</head>
<body>
	<!--Header navigation-->
	<?php include 'header.php'; ?>
	<!--End of Header navigation-->

	<!--Main content navigation-->
	<section class="section-container-one">
		<div class="container-one">
		<div class="section-one-leftside">
		<h1 class="container-one-header">Notes refined for <span class="container-one-header-highlight-text">simplicity</span></h1>
		<p class="container-one-description">
		 eznotes, a fully flexible note site that offers wide variety of notes that could help you win battles against outstanding subjects
		and contribute great insights.
		</p>
		<a class="container-one-btn">
			EXPLORE NOW
		<img class="arrow" src="/Note/content/assets/images/arrow2.png">
		</a>
		</div>
		<div class="section-one-rightside">
		<img class="container-one-main-image" src="/Note/content/assets/images/someonestudying.jpg">
		</div>
		</div>
	</section>

	<section class="section-container-two">
		<div class="container-two">
			<h2 class="container-two-header">Landing Performance</h2>
			<p class="container-two-description">eznotes utilizes its performance with the intuitive note</p>
			<p class="container-two-description2">taking interface, flexible management system and security & privacy.</p>
			<p class="container-two-description3">The quality learning resource available is obtained</p>
			<p class="container-two-description4">from the <span class="container-two-description-highlight">finest</span>.</p>
		</div>
	</section>

	<section class="section-container-three">
		<div class="container-three">

		<div class="container-three-contentone">
			<img class="contentone-icon" src="/Note/content/assets/images/sectionthree-icon1.png">
			<h2 class="contentone-header">Comment system for you</h2>
			<p class="contentone-description">Users can provide their thoughts and questions regarding subjects with the comment utility of eznotes.</p>
		</div>

		<div class="container-three-contenttwo">
			<img class="contenttwo-icon" src="/Note/content/assets/images/sectionthree-icon2.png">
			<h2 class="contenttwo-header">Powerful engine</h2>
			<p class="contenttwo-description">The integration of JavaScript with the site results an excellent interactivity and overall user-friendly.</p>
		</div>

		<div class="container-three-contentthree">
			<img class="contentthree-icon" src="/Note/content/assets/images/sectionthree-icon3.png">
			<h2 class="contentthree-header">Speed optimization</h2>
			<p class="contentthree-description">The built-in speed optimization ensure users experience swift performance during their knowledge exploration.</p>
		</div>


		</div>
	</section>

	<?php include 'footer.php'; ?>

	<script>
document.addEventListener("DOMContentLoaded", function() {
    // Add the fade-in class to trigger the animation for section-one
    var leftSide = document.querySelector('.section-one-leftside');
    setTimeout(function() {
        leftSide.classList.add('fade-in');
    }, 50); // Adjust the delay as needed

    var rightSide = document.querySelector('.section-one-rightside');
    setTimeout(function() {
        rightSide.classList.add('fade-in');
    }, 50); // Adjust the delay as needed

    // Add the fade-in class to trigger the animation for section-container-two
    var containerTwo = document.querySelector('.section-container-two .container-two');
    function isElementInViewport(element) {
        var rect = element.getBoundingClientRect();
        return (
            rect.top >= 0 &&
            rect.left >= 0 &&
            rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
            rect.right <= (window.innerWidth || document.documentElement.clientWidth)
        );
    }

    function handleScroll() {
        if (isElementInViewport(containerTwo) && !containerTwo.classList.contains('fade-in')) {
            containerTwo.classList.add('fade-in');
        }
    }

    // Initial check on page load
    handleScroll();

    // Listen for scroll events
    window.addEventListener('scroll', handleScroll);

    // Add the fade-in class to trigger the animation for section-container-three
    var sectionThree = document.querySelector('.section-container-three');
    var containerThree = document.querySelector('.container-three');

    function fadeInContent() {
        containerThree.classList.add('fade-in');
    }

    function handleScrollSectionThree() {
        if (isElementInViewport(sectionThree) && !containerThree.classList.contains('fade-in')) {
            fadeInContent();
        }
    }

    // Listen for scroll events for section-container-three
    window.addEventListener('scroll', handleScrollSectionThree);
});


</script>


	

	<!--End of Main content navigation-->


</body>
</html>