<?php include 'server.php'; ?>
<?php include 'functions.php'; ?>
<?php
 session_start();


    $userImage = ($_SESSION['admin']['userimage'] ?? '') ?: ($_SESSION['user']['userimage'] ?? '');
    $userStudentID = ($_SESSION['admin']['studentID'] ?? '') ?: ($_SESSION['user']['studentID'] ?? '');
    $fullname = ($_SESSION['admin']['fullname'] ?? '') ?: ($_SESSION['user']['fullname'] ?? '');
    $email = ($_SESSION['admin']['email'] ?? '') ?: ($_SESSION['user']['email'] ?? '');
    $studentpassword = ($_SESSION['admin']['password'] ?? '') ?: ($_SESSION['user']['password'] ?? '');




getSubjectInformation();

error_log('POST data: ' . print_r($_POST, true));
$selectedSubjectId = $_POST['selectedSubjectId'] ?? 'Not set';
error_log('Selected Subject ID: ' . $selectedSubjectId);

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["addsubjectbtn"])) {
    if (isset($_POST["add_subjectid"]) && isset($_POST["add_subjectname"])) {
        $subject_id = $_POST["add_subjectid"];
        $subject_name = $_POST["add_subjectname"];

        // Call the addSubject function
        $inserted = addSubject($conn, $subject_id, $subject_name);

    }
}


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['editsubjectbtn'])) {
    if (isset($_POST["edit_subject_id"]) && isset($_POST["edit_subject_name"])) {
        $edit_subject_id = $_POST["edit_subject_id"];
        $edit_subject_name = $_POST["edit_subject_name"];

        // Call the editSubject function
        editSubject($conn, $edit_subject_id, $edit_subject_name);
    }
    // Don't forget to close the connection after using it if needed
    $conn->close();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['deletesubjectbtn'])) {
    // Decode the JSON data sent from JavaScript
    $subjectJson = json_decode($_POST['delete_subject_json'], true);

    // Extract subject ID from the subject JSON
    $subjectId = $subjectJson['subject_id'];

    // Call the deleteSubject function
    $deleteResult = deleteSubject($conn, $subjectId);

    // Send JSON response
    echo json_encode($deleteResult);
    exit();
}




$userRole = isset($_SESSION['admin']) ? 'admin' : (isset($_SESSION['user']) ? 'user' : '');

$userRoleJSON = json_encode($userRole);



?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="./assets/css/styles.css" />
    <link rel="stylesheet" href="./assets/css/style.css" />
	<link rel="icon" href="/Note/content/assets/images/tablogo.jpg" type="image/x-icon">
	<title>eznotes</title>
</head>
<body>
    <!--Header navigation-->
	<?php include 'dashboard-header.php'; ?>
	<!--End of Header navigation-->


       <!--Tools-section navigation-->
	<?php include 'tools-section.php'; ?>
	<!--End of Tools-section navigation-->

    <div id="foldercontentcontainer" class="folder-content-container">
    <table>
        <thead>
            <tr>
                <th class="folder-table-header">
                    <span class="table-header-subjectname">Subject</span>
                    <hr class="firsthrtable">
                </th>
                <th class="folder-table-header">
                    <span class="table-header-topics">Topics</span>
                    <hr class="secondhrtable">
                </th>
                <th class="folder-table-header">
                    <span class="table-header-lastadded">Last added</span>
                    <hr class="thirdhrtable">
                </th>
            
            </tr>
        </thead>
        <tbody class="folder-table-bodycontent">
     
   <?php
// Loop through each subject in the array and populate the table rows

foreach ($subjectinformation as $subject) {
    $uniqueId = 'moreOptionsButton_' . $subject['subject_id'];
    $editBtnId = 'editBtn_' . $subject['subject_id'];
    $deleteBtnId = 'deleteBtn_' . $subject['subject_id'];

    // Encode the subject information as JSON
    $subjectJson = json_encode($subject);

    echo '<tr class="subject-record" data-subject-id="' . $subject['subject_id'] . '" data-subject-name="' . htmlspecialchars($subject['subject_name'], ENT_QUOTES, 'UTF-8') . '">';
    echo '<td><div class="subject-container"> <img class="folder-image" src="/Note/content/assets/images/folder.png" alt="Folder Icon"><span class="subject-id">' . $subject['subject_id'] . '</span> <span style="font-size:10px; margin-top:-17px; color:grey;" class="subject-name">' . $subject['subject_name'] . '</span></div></td>';
    echo '<td><div class="num-topics-container"><span class="num-topics">' . $subject['num_topics'] . '</span></div></td>';
    echo '<td><div class="subject-created-container"><span class="subject-created">' . date('Y-m-d', strtotime($subject['subject_created'])) . '</span></div></td>';
    echo '<td>';
    echo '<div class="action-buttons">';
    echo '<button id="favouriteButton" type="submit" name="subjectFormSubmit" class="favourite-button"><img src="/Note/content/assets/images/favourite.png"></button>';
    if (isset($_SESSION['admin'])) {
    echo '<button class="more-options-button" id="' . $uniqueId . '"><img src="/Note/content/assets/images/moreoptions.png"></button>';
    echo '<div class="more-options-container" id="' . $uniqueId . '_container">';
    echo '<ul>';
    echo '<li id="' . $editBtnId . '" class="edit-btn" data-subject-json=\'' . htmlspecialchars($subjectJson, ENT_QUOTES, 'UTF-8') . '\'><img src="/Note/content/assets/images/edit.png">Edit</li>';
    echo '<hr>';
    echo '<li id="' . $deleteBtnId . '" class="delete-btn" data-subject-json=\'' . htmlspecialchars($subjectJson, ENT_QUOTES, 'UTF-8') . '\'><img src="/Note/content/assets/images/delete.png">Delete</li>';

    // Add more options as needed
    echo '</ul>';
    }
    echo '</div>';
    echo '</div>';
    echo '</td>';
    echo '</tr>';
    echo '<input type="hidden" name="selectedSubjectId" value="' . $subject['subject_id'] . '">';

}

?>



        </tbody>
    </table>
</div>

<div id="topicfiletablecontentcontainer" class="topic-file-tablecontent-container">
    <div class="topicfile-tablecontent-header">
        <div class="redirectbacktosubject-breadcrumbs">
            <button class="back-to-subject"><img class="left-arrow" src="/Note/content/assets/images/leftarrow.png">Return to subject selection</button>
            <button class="back-to-topic"><img class="left-arrow" src="/Note/content/assets/images/leftarrow.png">Return to topic selection</button>
            <span id="subjectnamedatacrumb" class="topic-breadcrumbs"></span>
        </div>
        <h3 id="subjectidtopic" class="topicfile-primary-header"></h3>
    </div>

    <div class="topicfile-tablecontent">
       <!-- topic-container goes here from the java script.  -->
    </div>

    <div class="main-comment-container">
        <div class="comment-header-container">
            <h3 id="commentcount" class="comment-count">Comments</h3>
            <button class="comment-sortby-button">
            <img class="comment-filter-image" src="/Note/content/assets/images/sort-by-comment.png">
            <span class="comment-filter-span">Sort by</span>
            </button>

        </div>
    <div class="your-comment-container">
    
        <div class="userprofile-yourcommentinput-container">
        <div class="yourcomment-circular-user-profile">
            <img class="youruserprofile-comment" src="<?php echo $userImage; ?>">
        </div>

        <div class="yourcomment-input-container">
        <textarea class="yourcomment-input-style" name="yourcomment-input" id="yourcommentinput" placeholder="Add a comment..."></textarea>
        </div>
        </div>

        <div class="yourcomment-emoji-cancelcomment-container" hidden>
            <button class="yourcomment-emoji-button"><img src="/Note/content/assets/images/emoji.png"></button>
            <button class="yourcomment-cancel-button" name="cancelyrcommentbutton" id="cancelyrcommentbtn">Cancel</button>
            <button class="yourcomment-comment-button" name="yrcommentbutton" id="yrcommentbtn" disabled>Comment</button>
        </div>
        
    </div>

    <div class="all-comments">
      <!-- Comment-container goes here from the java script.  -->
    </div>
</div>


</div>




    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="./assets/js/moreoptions.js"></script>
    <script src="./assets/js/deletesubjects.js"></script>
    
    <script>
   document.addEventListener("DOMContentLoaded", function () {
    var subjectinfoCompare = <?php echo json_encode($subjectinformation); ?>;

    function AddSubjectValidationProcess() {
    var inputaddsubjectid = document.getElementById("addsubjectid-input").value;
    var inputaddsubjectname = document.querySelector('input[name="add_subjectname"]').value;

    var isSubjectIDExist = false;

    // Check if inputaddsubjectid is not empty
    if (inputaddsubjectid.trim() !== '') {
        // Loop through the subjectinfoCompare array
        for (var i = 0; i < subjectinfoCompare.length; i++) {
            var subject = subjectinfoCompare[i];

            if (subject.subject_id === inputaddsubjectid) {
                isSubjectIDExist = true;
                break;
            }
        }
    }
    // Check if both input fields are filled
    var areBothInputsFilled = inputaddsubjectid.trim() !== '' && inputaddsubjectname.trim() !== '';

    // Set visibility and style based on the result of the comparison for subjectid
    document.getElementById("addsubjectid-input").style.borderColor = isSubjectIDExist ? "red" : "";
    document.getElementById("addsubjectid-message-alert").style.visibility = isSubjectIDExist ? "visible" : "hidden";

    // Enable the "Create" button if both input fields are filled and subject ID does not exist
    document.getElementById("addsubject-btn").disabled = !areBothInputsFilled || isSubjectIDExist;
}

    // Attach the AddSubjectValidationProcess function to the input events
    document.getElementById("addsubjectid-input").addEventListener("input", AddSubjectValidationProcess);
    document.querySelector('input[name="add_subjectname"]').addEventListener("input", AddSubjectValidationProcess);

    // Run the AddSubjectValidationProcess function initially
    AddSubjectValidationProcess();
});


    </script>


<script>
    var openEditContainer = null;
    var editButtons = document.getElementsByClassName('edit-btn');
    var editSubjectIdInput = document.getElementsByName('edit_subject_id')[0];
    var editSubjectNameInput = document.getElementsByName('edit_subject_name')[0];
    var editSubjectContainer = document.getElementById('editSubjectContainer');
    var overlay = document.getElementById('overlay');
    var closeButton = document.getElementById('editcontainer-closeButton');
    var excludedEditSubjectValues; // Move the declaration here

    // Function to fetch subject information and populate the edit container
    function fetchSubjectInformationForEdit(subjectId) {
        // Create a new XMLHttpRequest object
        var xhr = new XMLHttpRequest();

        // Define the PHP script URL
        var phpScriptURL = 'functions.php';

        // Prepare the data to be sent
        var data = 'action=get_subject_info&subject_id=' + encodeURIComponent(subjectId);

        // Set up the request
        xhr.open('POST', phpScriptURL, true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

        // Define the callback function to handle the response
        xhr.onreadystatechange = function () {
            if (xhr.readyState === XMLHttpRequest.DONE) {
                if (xhr.status === 200) {
                    // Log the raw response
                    console.log('Raw Response:', xhr.responseText);
                    var subjecedittinfoCompare = <?php echo json_encode($subjectinformation); ?>;

                    // Parse the JSON data from the response
                    var subjectArray = JSON.parse(xhr.responseText);

                    // Assuming the first subject in the array is the relevant one
                    var selectedSubject = subjectArray[0];

                    // Access the required values from the selected subject
                    var selectedSubjectId = selectedSubject.subject_id;
                    var selectedSubjectName = selectedSubject.subject_name;

                    // Populate the input fields in the edit container
                    editSubjectIdInput.value = selectedSubjectId;
                    editSubjectNameInput.value = selectedSubjectName;

                    // Toggle the 'visible' class for the edit container and overlay
                    editSubjectContainer.classList.toggle('visible');
                    overlay.classList.toggle('visible');
                    openEditContainer = editSubjectContainer.classList.contains('visible') ? editSubjectContainer : null;

                    // Compare and create a new variable with values excluding matched items
                    excludedEditSubjectValues = subjecedittinfoCompare.filter(function (subject) {
                        // Check if the subject exists in subjectArray
                        return subjectArray.every(function (fetchedSubject) {
                            return fetchedSubject.subject_id !== subject.subject_id;
                        });
                    });

                    // Log the new variable
                    console.log('Excluded Values:', excludedEditSubjectValues);
                } else {
                    console.error('Error fetching subject information:', xhr.status);
                }
            }
        };

        // Send the request with the data
        xhr.send(data);
    }

    // Iterate through each 'edit-btn' and attach the event listener
    for (var i = 0; i < editButtons.length; i++) {
        editButtons[i].addEventListener('click', function (e) {
            // Find the corresponding 'edit-subject-container' based on the button's ID
            var editBtnId = this.id;

            // Extract subject ID from the button's ID
            var subjectId = editBtnId.replace('editBtn_', '');
            // Call the function to fetch subject information and populate the edit container
            fetchSubjectInformationForEdit(subjectId);

            // Stop the click event from propagating to the document
            e.stopPropagation();
        });
    }

    // Add a mousedown event listener to the overlay to close the edit container when clicking outside
    overlay.addEventListener('mousedown', function (e) {
        if (openEditContainer && !openEditContainer.contains(e.target)) {
            openEditContainer.classList.remove('visible');
            overlay.classList.remove('visible');
            openEditContainer = null;
        }
    });

    // Add an event listener for the close button
    closeButton.addEventListener('click', function () {
        if (openEditContainer) {
            openEditContainer.classList.remove('visible');
            overlay.classList.remove('visible');
            openEditContainer = null;
        }
    });

    document.addEventListener('DOMContentLoaded', function () {

        function EditSubjectValidationProcess() {
            var inputeditsubjectid = document.getElementById("editsubjectid-input").value;
            var inputeditsubjectname = document.querySelector('input[name="edit_subject_name"]').value;

            var iseditSubjectIDExist = false;

            // Check if inputaddsubjectid is not empty
            if (inputeditsubjectid.trim() !== '') {
                // Loop through the excludedEditSubjectValues array
                for (var i = 0; i < excludedEditSubjectValues.length; i++) {
                    var subject = excludedEditSubjectValues[i];

                    if (subject.subject_id === inputeditsubjectid) {
                        iseditSubjectIDExist = true;
                        break;
                    }
                }
            }
            // Check if both input fields are filled
            var areBothInputsFilled = inputeditsubjectid.trim() !== '' && inputeditsubjectname.trim() !== '';

            // Set visibility and style based on the result of the comparison for subjectid
            document.getElementById("editsubjectid-input").style.borderColor = iseditSubjectIDExist ? "red" : "";
            document.getElementById("editsubjectid-message-alert").style.visibility = iseditSubjectIDExist ? "visible" : "hidden";

            // Enable the "Edit" button if both input fields are filled and subject ID does not exist
            document.getElementById("editsubject-button").disabled = !areBothInputsFilled || iseditSubjectIDExist;
        }

        // Attach the EditSubjectValidationProcess function to the input events
        document.getElementById("editsubjectid-input").addEventListener("input", EditSubjectValidationProcess);
        document.querySelector('input[name="edit_subject_name"]').addEventListener("input", EditSubjectValidationProcess);

        // Run the EditSubjectValidationProcess function initially
        EditSubjectValidationProcess();
    });

</script>



<script>
document.addEventListener("DOMContentLoaded", function () {
    var rows = document.querySelectorAll('.subject-record');
    var backButton = document.querySelector('.back-to-subject');
    var subjectNameDataCrumb = document.getElementById('subjectnamedatacrumb');
    var subjectIdTopic = document.getElementById('subjectidtopic');
    var topicFileTableContainer; // Declare the variable here
    var isAnimating = false;
    var userRole = <?php echo $userRoleJSON; ?>;

    function toggleContainers(event) {
    if (!isAnimating) {
        isAnimating = true;

        var folderContentContainer = document.getElementById('foldercontentcontainer');
        topicFileTableContainer = document.getElementById('topicfiletablecontentcontainer');
        var selectedSubjectId = event.currentTarget.dataset.subjectId;
        var selectedSubjectName = event.currentTarget.dataset.subjectName;

        // Check if the session information is available
        if  (userRole === 'admin' || userRole === 'user' ) {
            // Show the content containers
            folderContentContainer.classList.remove('visible');
            folderContentContainer.classList.toggle('invisible');

            topicFileTableContainer.classList.remove('invisible');
            topicFileTableContainer.classList.toggle('visible');
        } else {
            // Show the must-login container
            var overlay = document.getElementById('overlay');
            var mustLoginContainer = document.getElementById('mustlogincontainer');
            var closeButton = document.getElementById('closelogincontainer-closeButton');
            mustLoginContainer.classList.toggle('visible');
            overlay.classList.toggle('visible');

            closeButton.addEventListener('click', function () {
    // Hide the must-login container
    var mustLoginContainer = document.getElementById('mustlogincontainer');
    mustLoginContainer.classList.remove('visible');
  

    // Hide the overlay
    var overlay = document.getElementById('overlay');
    overlay.classList.remove('visible');
    
});


        }

        // Set the subject_id and subject_name as data attributes on topicFileTableContainer
        topicFileTableContainer.setAttribute('data-subject-id', selectedSubjectId);
        topicFileTableContainer.setAttribute('data-subject-name', selectedSubjectName);

        // Display the subject_id and subject_name in the specified elements
        subjectNameDataCrumb.textContent = selectedSubjectName;
        subjectIdTopic.textContent = selectedSubjectId + ' Subject Content';

        // Set a timeout to reset the animation state and enable the button after the transition duration
        setTimeout(function () {
            isAnimating = false;
            backButton.disabled = false; // Re-enable the button
        }, 800); // Adjust the timeout to match your transition duration

        // Disable the button during the animation
        backButton.disabled = true;

        document.querySelector('.all-comments').innerHTML = '';

        // Send the selectedSubjectId to the server using AJAX
        sendSelectedSubjectId(selectedSubjectId);
        retrieveComments(selectedSubjectId);
    }
}



    function sendSelectedSubjectId(selectedSubjectId) {
        var xhr = new XMLHttpRequest();
        xhr.open('POST', 'functions.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
        xhr.onreadystatechange = function () {
    if (xhr.readyState === 4) {
        if (xhr.status === 200) {
            // Handle the server's response if needed
         
            updateTopicContainer(xhr);  // Call the function with the xhr object
        } else {
            console.error('Error:', xhr.status);
        }
    }
};


        var data = 'action=getSelectedTopic&selectedSubjectId=' + encodeURIComponent(selectedSubjectId);
        xhr.send(data);
    }



    function displayTopicMoreOptions(event) {
    // Find the closest topic-container to the clicked button
    var topicContainer = event.target.closest('.topic-container');

    // Check if a topic-container was found
    if (topicContainer) {
        // Find the options container within the topic-container
        var topicOptionsContainer = topicContainer.querySelector('.topic-options-container');

        // Toggle the visibility if the options container is found
        if (topicOptionsContainer) {
            topicOptionsContainer.classList.toggle('visible');
        }

        // Find the Rename button within the options container
        var renameButton = topicOptionsContainer.querySelector('.rename-button');

        // Add event listener for click events on the Rename button
        if (renameButton) {
            renameButton.addEventListener('click', function (event) {
                event.stopPropagation();
                // Call the RenameTopic function when the Rename button is clicked
                RenameTopic(event);
            });
        }

        // Stop the click event from propagating up the DOM tree
        event.stopPropagation();
    }
}

// Close options container when clicking outside
document.addEventListener('click', function (event) {
    // Find the options container that is currently visible
    var visibleOptionsContainer = document.querySelector('.topic-options-container.visible');

    // Check if the clicked element is not within the visible options container
    if (visibleOptionsContainer && !visibleOptionsContainer.contains(event.target)) {
        // Hide the options container
        visibleOptionsContainer.classList.remove('visible');
    }
});

// Close options container when clicking outside
document.addEventListener('click', function (event) {
    // Find the options container that is currently visible
    var visibleOptionsContainer = document.querySelector('.topic-options-container.visible');

    // Check if the clicked element is not within the visible options container
    if (visibleOptionsContainer && !visibleOptionsContainer.contains(event.target)) {
        // Hide the options container
        visibleOptionsContainer.classList.remove('visible');
    }
});




function updateTopicContainer(xhr) {
    // Log the raw response for inspection

    // Attempt to parse the JSON response
    try {
        var topicArray = JSON.parse(xhr.responseText);

        topicArray.sort(function(a, b) {
    // Extract numerical values from the topic names
    var numA = parseInt(a.topic_name.match(/\d+/), 10) || 0;
    var numB = parseInt(b.topic_name.match(/\d+/), 10) || 0;

    // Compare the numerical values
    return numA - numB;
});
        // Get the topicfile-tablecontent container
        var topicFileTableContent = document.querySelector('.topicfile-tablecontent');

        // Clear the existing content
        topicFileTableContent.innerHTML = '';

        // Check if topics are available
        if (topicArray.length > 0) {
            // Create the grid-view container
            var gridView = document.createElement('div');
            gridView.className = 'grid-view';

            // Loop through each topic and create HTML elements
            topicArray.forEach(function (topic, index) {
                // Create the topic container
                var topicContainer = document.createElement('div');
                topicContainer.className = 'topic-container';
                topicContainer.dataset.topicId = topic['topic_id']; 

    
             
                // Create the topic image
                var topicImage = document.createElement('div');
                topicImage.className = 'topic-image';
                topicImage.innerHTML = '<img src="/Note/content/assets/images/subfolder2.png">';

                // Create the topic name and options container
                var topicNameOptions = document.createElement('div');
                topicNameOptions.className = 'topic-name-options';

                // Create the topic name span
                var topicNameSpan = document.createElement('span');
                topicNameSpan.className = 'topicname';
                topicNameSpan.textContent = topic['topic_name'];

                

                // Create the more options button
                var moreOptionsButton = document.createElement('button');
                moreOptionsButton.className = 'moreoptions-topic';
                moreOptionsButton.innerHTML = '<img src="/Note/content/assets/images/moreoptions.png">';

                // Create the options container with a unique ID
                var optionsContainer = document.createElement('div');
                optionsContainer.className = 'topic-options-container';
                optionsContainer.id = 'optionsContainer_' + index;

                // Create the options list
                var optionsList = document.createElement('ul');

                // Create the rename button
                var renameButton = document.createElement('li');
                renameButton.className = 'rename-button';
                renameButton.textContent = 'Rename';

                // Create the horizontal rule
                var horizontalRule = document.createElement('hr');

                // Create the delete button
                var deleteButton = document.createElement('li');
                deleteButton.className = 'delete-button';
                deleteButton.textContent = 'Delete';

                deleteButton.addEventListener('click', function (event) {
                    event.stopPropagation();
    var topicContainer = event.target.closest('.topic-container');

    if (topicContainer) {
        var topicNameSpan = topicContainer.querySelector('.topicname');
        currentTopicId = topicContainer.dataset.topicId;

        if (topicNameSpan && currentTopicId) {
            // Call the showDeleteTopicContainer function
            showDeleteTopicContainer(currentTopicId, topicNameSpan.textContent);
        }
    }
});

// Add event listener to the confirm delete button inside the delete topic container
var confirmDeleteButton = document.getElementById('deletetopic-button');
confirmDeleteButton.addEventListener('click', function () {
    // Get the topic container (it's the same as the one used in showDeleteTopicContainer)
    var topicContainer = document.querySelector('.topic-container[data-topic-id="' + currentTopicId + '"]');

    // Call the sendDeleteTopicRequest function
    sendDeleteTopicRequest(topicContainer);
    hideDeleteTopicContainer(); // Also hide the container after sending the request
});

// Add event listener to the close button
var closeButton = document.getElementById('deletetopiccontainer-closeButton');
closeButton.addEventListener('click', hideDeleteTopicContainer);

var cancelButton = document.getElementById('deletecontainertopic-cancelButton');
cancelButton.addEventListener('click', hideDeleteTopicContainer);


                // Append elements to the options list
                optionsList.appendChild(renameButton);
                optionsList.appendChild(horizontalRule);
                optionsList.appendChild(deleteButton);

                // Append the options list to the options container
                optionsContainer.appendChild(optionsList);

                // Append elements to the topic container
                topicNameOptions.appendChild(topicNameSpan);
                if (userRole === 'admin') {
                topicNameOptions.appendChild(moreOptionsButton);
                topicNameOptions.appendChild(optionsContainer);
                }
                topicContainer.appendChild(topicImage);
                topicContainer.appendChild(topicNameOptions);

                // Append the topic container to the grid-view
                gridView.appendChild(topicContainer);

               

                // Check if it's the last topic
                if (index === topicArray.length - 1) {
                    // Create the add-topic-button
                    var addTopicButton = document.createElement('button');
                    addTopicButton.className = 'add-topic-button';

                    // Create the add-topic-image
                    var addTopicImage = document.createElement('img');
                    addTopicImage.src = '/Note/content/assets/images/addtopic.png'; // Set the actual image source
                    addTopicImage.alt = 'add-topic-image';

                    // Create a span
                    var buttonText = document.createElement('span');
                    buttonText.textContent = 'Add Topic'; // Set the text content

                    // Append the add-topic-image and span to the add-topic-button
                    addTopicButton.appendChild(addTopicImage);
                    addTopicButton.appendChild(buttonText);
                    if (userRole === 'admin') {
                    // Append the add-topic-button to the grid-view
                    gridView.appendChild(addTopicButton);
                    }
                }
            });

            // Append the grid-view to the topicfile-tablecontent
            topicFileTableContent.appendChild(gridView);



            gridView.addEventListener('click', function (event) {
    // Check if the clicked element or its parent has the class 'moreoptions-topic'
    var moreOptionsButton = event.target.closest('.moreoptions-topic');

    if (moreOptionsButton) {
        // If found, call the displayTopicMoreOptions function
        displayTopicMoreOptions(event);
    } else {
        
        // Check if the clicked element or its parent has the class 'topic-container'
        var topicContainer = event.target.closest('.topic-container');

        if (topicContainer) {
            // If found, call the retrieveTopicFiles function with the topicId
            retrieveTopicFiles(topicContainer.dataset.topicId);
        } else if (event.target.classList.contains('grid-view')) {
            // If the click is on the grid-view but not on a moreoptions-topic or topic-container,
            // close any open topic-options-container
            var openContainers = document.querySelectorAll('.topic-options-container.visible');
            openContainers.forEach(function (container) {
                container.classList.remove('visible');
            });
        }
    }
});



            
        } else {
            if (userRole === 'admin') {

                var gridView = document.createElement('div');
                gridView.className = 'grid-view';
                // Create the add-topic-button
                var addTopicButton = document.createElement('button');
                addTopicButton.className = 'add-topic-button';

                // Create the add-topic-image
                var addTopicImage = document.createElement('img');
                addTopicImage.src = '/Note/content/assets/images/addtopic.png'; // Set the actual image source
                addTopicImage.alt = 'add-topic-image';

                // Create a span
                var buttonText = document.createElement('span');
                buttonText.textContent = 'Add Topic'; // Set the text content

                // Append the add-topic-image and span to the add-topic-button
                addTopicButton.appendChild(addTopicImage);
                addTopicButton.appendChild(buttonText);

                // Append the add-topic-button to the grid-view
                gridView.appendChild(addTopicButton);

        // Append the add-topic-button to the grid-view
        topicFileTableContent.appendChild(gridView);
                

            }else{
                  // Display a message if no topics are available
        topicFileTableContent.innerHTML = '<div class="outoftopic-container"><img src="/Note/content/assets/images/outofnotes.png" class="outoftopic-image" alt="Out of Notes Image"><h3 class="outoftopic-header">No available topics for now.</h3></div>';
            }
      

        }
    } catch (error) {
        console.error('Error parsing JSON:', error);
    }
}



function addNewTopic() {
    // Check if there's an existing topic being edited
    var existingInput = document.querySelector('.topic-container input');
    if (existingInput) {
        // If an input exists, don't create a new topic
        return;
    }

    // Declare gridView before using it
    var gridView = document.querySelector('.grid-view');

    // Create the new topic container
    var newTopicContainer = document.createElement('div');
    newTopicContainer.className = 'topic-container';

    // Create the topic image
    var topicImage = document.createElement('div');
    topicImage.className = 'topic-image';
    topicImage.innerHTML = '<img src="/Note/content/assets/images/subfolder2.png">';

    // Create the topic name and options container
    var topicNameOptions = document.createElement('div');
    topicNameOptions.className = 'topic-name-options';

    // Create the topic name input
    var topicNameInput = document.createElement('input');
    topicNameInput.type = 'text'; // Set input type to text
    topicNameInput.className = 'topicname';
    topicNameInput.placeholder = 'Enter topic name'; // Set a placeholder if needed

    // Create the more options button
    var moreOptionsButton = document.createElement('button');
    moreOptionsButton.className = 'moreoptions-topic';
    moreOptionsButton.innerHTML = '<img src="/Note/content/assets/images/moreoptions.png">';

    // Add event listener for more options button
    moreOptionsButton.addEventListener('click', function (event) {
        var moreOptionsButton = event.target.closest('.moreoptions-topic');
        if (moreOptionsButton) {
            displayTopicMoreOptions(event);
        }
    });

    // Create the options container
    var optionsContainer = document.createElement('div');
    optionsContainer.className = 'topic-options-container';

    // Create the options list
    var optionsList = document.createElement('ul');

    // Create the rename button
    var renameButton = document.createElement('li');
    renameButton.className = 'rename-button';
    renameButton.textContent = 'Rename';

    // Create the horizontal rule
    var horizontalRule = document.createElement('hr');

    // Create the delete button
    var deleteButton = document.createElement('li');
    deleteButton.className = 'delete-button';
    deleteButton.textContent = 'Delete';


    deleteButton.addEventListener('click', function (event) {
        event.stopPropagation();
    var topicContainer = event.target.closest('.topic-container');

    if (topicContainer) {
        var topicNameSpan = topicContainer.querySelector('.topicname');
        currentTopicId = topicContainer.dataset.topicId;

        if (topicNameSpan && currentTopicId) {
            // Call the showDeleteTopicContainer function
            showDeleteTopicContainer(currentTopicId, topicNameSpan.textContent);
        }
    }
});

// Add event listener to the confirm delete button inside the delete topic container
var confirmDeleteButton = document.getElementById('deletetopic-button');
confirmDeleteButton.addEventListener('click', function () {
    // Get the topic container (it's the same as the one used in showDeleteTopicContainer)
    var topicContainer = document.querySelector('.topic-container[data-topic-id="' + currentTopicId + '"]');

    // Call the sendDeleteTopicRequest function
    sendDeleteTopicRequest(topicContainer);
    hideDeleteTopicContainer(); // Also hide the container after sending the request
});

// Add event listener to the close button
var closeButton = document.getElementById('deletetopiccontainer-closeButton');
closeButton.addEventListener('click', hideDeleteTopicContainer);

var cancelButton = document.getElementById('deletecontainertopic-cancelButton');
cancelButton.addEventListener('click', hideDeleteTopicContainer);

    // Append elements to the options list
    optionsList.appendChild(renameButton);
    optionsList.appendChild(horizontalRule);
    optionsList.appendChild(deleteButton);

    // Append the options list to the options container
    optionsContainer.appendChild(optionsList);

    // Append elements to the topic container
    topicNameOptions.appendChild(topicNameInput);
    topicNameOptions.appendChild(moreOptionsButton);
    topicNameOptions.appendChild(optionsContainer); // Append options container here
    newTopicContainer.appendChild(topicImage);
    newTopicContainer.appendChild(topicNameOptions);

    // Append the new topic container to the grid-view
    gridView.appendChild(newTopicContainer);

    
    topicNameInput.addEventListener('click', function (event) {
                event.stopPropagation();
            });

    // Add event listener for key press events on the input
    topicNameInput.addEventListener('keyup', function (event) {
        if (event.key === 'Enter') {
            // Save the input and convert it back to a span
            var topicNameSpan = document.createElement('span');
            topicNameSpan.className = 'topicname';
            topicNameSpan.textContent = topicNameInput.value;

            // Replace the input with the span
            topicNameOptions.replaceChild(topicNameSpan, topicNameInput);

            enableAddTopicButton();

            // Send the data to the server and set the topicId when the response is received
            addNewTopicToServer(topicFileTableContainer.getAttribute('data-subject-id'), topicNameInput.value, newTopicContainer);

            sortTopicsAlphabetically();
        } else if (event.key === 'Escape') {
            // Remove the newly created container
            gridView.removeChild(newTopicContainer);

            enableAddTopicButton();
        }
    });
    disableAddTopicButton();
}

// Modify addNewTopicToServer function to include the newTopicContainer parameter
function addNewTopicToServer(selectedSubjectId, topicName, newTopicContainer) {
    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'functions.php', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                // Handle the server's response
                var response = JSON.parse(xhr.responseText);
               

                if (response.status === 'success') {
                    // Server successfully added the topic, set the topicId for the new topic container
                    newTopicContainer.dataset.topicId = response.topicId;
                } else {
                    console.error('Error adding new topic:', response.message);
                    // Handle the error if needed
                }
            } else {
                console.error('Error:', xhr.status);
            }
        }
    };

    var data = 'action=addNewTopic&selectedSubjectId=' + encodeURIComponent(selectedSubjectId) +
               '&topicName=' + encodeURIComponent(topicName);
    xhr.send(data);
}


function sortTopicsAlphabetically() {
    var gridView = document.querySelector('.grid-view');
    var topicContainers = Array.from(gridView.getElementsByClassName('topic-container'));

    // Sort the topic containers numerically by extracting and comparing numerical values from topic names
    topicContainers.sort(function (a, b) {
        var topicNameA = a.querySelector('.topicname').textContent;
        var topicNameB = b.querySelector('.topicname').textContent;

        // Extract numerical values from the topic names
        var numA = parseInt(topicNameA.match(/\d+/), 10) || 0;
        var numB = parseInt(topicNameB.match(/\d+/), 10) || 0;

        // Compare the numerical values
        return numA - numB;
    });

    // Clear the existing content in the grid-view
    gridView.innerHTML = '';

    // Append the sorted topic containers to the grid-view
    topicContainers.forEach(function (topicContainer, index) {
        gridView.appendChild(topicContainer);

    
    });

    // Add the "Add Topic" button at the end
    var addTopicButton = document.createElement('button');
    addTopicButton.className = 'add-topic-button';
    var addTopicImage = document.createElement('img');
    addTopicImage.src = '/Note/content/assets/images/addtopic.png'; // Set the actual image source
    addTopicImage.alt = 'add-topic-image';
    var buttonText = document.createElement('span');
    buttonText.textContent = 'Add Topic';
    addTopicButton.appendChild(addTopicImage);
    addTopicButton.appendChild(buttonText);
    gridView.appendChild(addTopicButton);
}




function sortFilesAlphabetically(topicId) {
    var gridView = document.querySelector('.grid-view');
    var fileContainers = Array.from(gridView.getElementsByClassName('file-container'));

    // Sort the file containers alphabetically by extracting and comparing file names
    fileContainers.sort(function (a, b) {
        var fileNameA = a.querySelector('.filename').textContent;
        var fileNameB = b.querySelector('.filename').textContent;

        // Compare file names
        return fileNameA.localeCompare(fileNameB);
    });

    // Clear the existing content in the grid-view
    gridView.innerHTML = '';

    // Append the sorted file containers to the grid-view
    fileContainers.forEach(function (fileContainer) {
        gridView.appendChild(fileContainer);
    });

    if (userRole === 'admin') {
    // Create the 'add-topicfile-container' div
    var addTopicFileContainer = document.createElement('div');
    addTopicFileContainer.className = 'add-topicfile-container';

    // Create the image element
    var addFileImage = document.createElement('img');
    addFileImage.src = '/Note/content/assets/images/files.png'; // Set the image source

    // Append the image to the 'add-topicfile-container'
    addTopicFileContainer.appendChild(addFileImage);

   // Create the 'addtopicfileinput-container' div
var addTopicFileInputContainer = document.createElement('div');
addTopicFileInputContainer.className = 'addtopicfileinput-container';
addTopicFileInputContainer.id = 'fileInputContainer';

// Create the label element
var addFileLabel = document.createElement('label');
addFileLabel.textContent = 'Add a file';

// Create a span to display the selected file name
var fileNameDisplay = document.createElement('span');

// Create the input type file
var addFileInput = document.createElement('input');
addFileInput.type = 'file';
addFileInput.id = 'fileInput'; // You can set a unique ID if needed
addFileInput.name = 'file'; // Set the name attribute to 'file'

// Add an event listener to the label for the click event
addFileLabel.addEventListener('click', function () {
    event.preventDefault();
    console.log('Label clicked');
    // Trigger a click on the associated file input
    addFileInput.click();
});

addFileInput.addEventListener('change', function (event) {
    // Get the selected file
    var selectedFile = event.target.files[0];

    // Log the selected file information (you can do further processing here)
    console.log('Selected File:', selectedFile);

    // Call the SendAddFileRequest function with the filename
    SendAddFileRequest(topicId, selectedFile.name, selectedFile);
});



// Set the 'for' attribute of the label to match the 'id' of the file input
addFileLabel.setAttribute('for', 'fileInput');

// Append the file input, label, and file name display to the file input container  
addTopicFileInputContainer.appendChild(addFileInput);
addTopicFileInputContainer.appendChild(addFileLabel);
addTopicFileInputContainer.appendChild(fileNameDisplay);

// Append the 'addtopicfileinput-container' to the 'add-topicfile-container'
addTopicFileContainer.appendChild(addTopicFileInputContainer);

// Append the 'add-topicfile-container' to the grid
gridView.appendChild(addTopicFileContainer);


}
   
}


function RenameTopic(event) {
    // Find the closest topic-container to the clicked button
    var topicContainer = event.target.closest('.topic-container');

    // Check if a topic-container was found
    if (topicContainer) {
        // Find the topic name span within the topic-container
        var topicNameSpan = topicContainer.querySelector('.topicname');

        // Check if a topic name span was found
        if (topicNameSpan) {
            // Create an input element
            var topicNameInput = document.createElement('input');
            topicNameInput.type = 'text';
            topicNameInput.className = 'renameinput';
            topicNameInput.value = topicNameSpan.textContent;

            // Replace the topic name span with the input element
            topicNameSpan.parentNode.replaceChild(topicNameInput, topicNameSpan);

            // Add event listener for key press events on the input
            topicNameInput.addEventListener('keyup', function (event) {
                if (event.key === 'Enter') {
                    // Save the input and convert it back to a span
                    var newTopicNameSpan = document.createElement('span');
                    newTopicNameSpan.className = 'topicname';
                    newTopicNameSpan.textContent = topicNameInput.value;

                    // Replace the input with the new span
                    topicNameInput.parentNode.replaceChild(newTopicNameSpan, topicNameInput);

                    // Send the updated data to the server
                    sendRenameTopicRequest(topicContainer, topicNameInput.value);
                } else if (event.key === 'Escape') {
                    // Restore the original span if the user presses Escape
                    topicNameInput.parentNode.replaceChild(topicNameSpan, topicNameInput);
                }
            });

            topicNameInput.addEventListener('click', function (event) {
                event.stopPropagation();
            });


        }
    }
}





function sendRenameTopicRequest(topicContainer, newTopicName) {
    // Get the topic ID from the container's data attribute or any other way you store it
    var topicId = topicContainer.dataset.topicId;

    // Create an AJAX request
    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'functions.php', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

    // Set up the data to be sent
    var data = 'action=RenameTopic&topicId=' + encodeURIComponent(topicId) + '&newTopicName=' + encodeURIComponent(newTopicName);

    // Set up the callback function
    xhr.onload = function () {
        if (xhr.status === 200) {
            // Handle the response from the server if needed
      
        }
    };

    // Send the request
    xhr.send(data);
}



// Function to show the delete topic container
function showDeleteTopicContainer(subjectId, topicName) {
    // Get the delete topic container
    var deleteTopicContainer = document.getElementById('deleteTopicContainer');

    // Get the overlay
    var overlay = document.querySelector('.overlay');

    // Get the input element for subject ID
    var deleteSubjectIdInput = document.getElementById('editsubjectid-input');

    // Set the subject ID in the input
    deleteSubjectIdInput.value = subjectId;

    // Update the delete subject message with the selected topic name
    document.getElementById('selected-topicdelete').textContent = topicName;

    // Show the delete topic container and overlay
    deleteTopicContainer.classList.add('visible');
    overlay.classList.add('visible');
}

// Function to hide the delete topic container and overlay
function hideDeleteTopicContainer() {
    // Get the delete topic container
    var deleteTopicContainer = document.getElementById('deleteTopicContainer');

    // Get the overlay
    var overlay = document.querySelector('.overlay');

    // Hide the delete topic container and overlay
    deleteTopicContainer.classList.remove('visible');
    overlay.classList.remove('visible');
}





function sendDeleteTopicRequest(topicContainer) {
    // Get the topic ID from the container's data attribute or any other way you store it
    var topicId = topicContainer.dataset.topicId;

    // Log the data being sent
    console.log('Sending data to server:', { action: 'deleteTopic', topicId: topicId });

    // Create an AJAX request
    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'functions.php', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

    // Set up the data to be sent
    var data = 'action=deleteTopic&topicId=' + encodeURIComponent(topicId);

    // Set up the callback function
    xhr.onload = function () {
        if (xhr.status === 200) {
            // Handle the response from the server if needed
            console.log('Server response:', xhr.responseText);

            // Parse the JSON response
            var response = JSON.parse(xhr.responseText);

            // Check the status in the response
            if (response.status === 'success') {
                // Handle success, e.g., remove the topic container from the UI
                hideDeleteTopicContainer();
                topicContainer.remove();
                sortTopicsAlphabetically();
            } else {
                // Handle error, e.g., show an error message
                console.error('Error:', response.message);
            }
        }
    };

    // Send the request
    xhr.send(data);
}



var selectedFileInfo = null;

function retrieveTopicFiles(topicId) {
    // Create a new XMLHttpRequest object
    var xhr = new XMLHttpRequest();

    // Set up the request
    xhr.open('POST', 'functions.php', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

    // Define the data to be sent in the request
    var data = 'action=retrieveTopicFiles&topicId=' + encodeURIComponent(topicId);

    // Set up the onload function to handle the response
    xhr.onload = function () {
        if (xhr.status >= 200 && xhr.status < 400) {
            // Parse the JSON response
            try {
                var response = JSON.parse(xhr.responseText);

                // Log the entire response for inspection
                console.log('Full Response:', response);

                // Check if the response has an 'error' field
                if (response.hasOwnProperty('error')) {
                    console.error('Error retrieving files:', response.error);
                } else {
                    // Call the updateTopicFiles function with the retrieved files
                    console.log('Retrieved Files:', response);
                    updateTopicFiles(response);
                }
            } catch (error) {
                console.error('Error parsing JSON:', error);
            }
        } else {
            console.error('Request failed with status:', xhr.status);
        }
    };

    // Set up the onerror function to handle errors
    xhr.onerror = function () {
        console.error('Request failed');
    };

    // Send the request with the data
    xhr.send(data);
}


function updateBackButton(isTopicView) {
    console.log('updateBackButton function called');
    var backButtonToSubject = document.querySelector('.back-to-subject');
    var backButtonToTopic = document.querySelector('.back-to-topic');

    if (backButtonToSubject && backButtonToTopic) {
        if (isTopicView) {
            backButtonToSubject.style.visibility = 'hidden';
            backButtonToTopic.style.visibility = 'visible';
        } else {
            backButtonToSubject.style.visibility = 'visible';
            backButtonToTopic.style.visibility = 'hidden';
        }
    }
}


function displayFileMoreOptions(event) {
    // Find the closest file-container to the clicked button
    var fileContainer = event.target.closest('.file-container');

    // Check if a file-container was found
    if (fileContainer) {
        // Find the options container within the file-container
        var fileOptionsContainer = fileContainer.querySelector('.file-options-container');

        // Toggle the visibility if the options container is found
        if (fileOptionsContainer) {
            fileOptionsContainer.classList.toggle('visible');
        }

        // Find the Rename button within the options container
        var renameFileButton = fileOptionsContainer.querySelector('.rename-button');

        // Add event listener for click events on the Rename button
        if (renameFileButton) {
            renameFileButton.addEventListener('click', function (event) {
                // Call the RenameFile function when the Rename button is clicked
                RenameFile(event);
            });
        }

        // Stop the click event from propagating up the DOM tree
        event.stopPropagation();

        // Add event listener to close options container when clicking outside
        document.addEventListener('click', function closeOptionsContainer(e) {
            // Check if the clicked element is not within the file-options-container
            if (!fileOptionsContainer.contains(e.target)) {
                // Close the options container
                fileOptionsContainer.classList.remove('visible');
                // Remove the event listener to avoid further checks
                document.removeEventListener('click', closeOptionsContainer);
            }
        });
    }
}


// Function to show the delete file container
function showDeleteFileContainer(fileName) {
    // Get the delete file container
    var deleteFileContainer = document.getElementById('deletefileContainer');

    // Get the overlay
    var overlay = document.querySelector('.overlay');

    // Update the delete file message with the selected file name
    document.getElementById('selected-filedelete').textContent = fileName;

    // Show the delete file container and overlay
    deleteFileContainer.classList.add('visible');
    overlay.classList.add('visible');
}

// Function to hide the delete file container
function hideDeleteFileContainer() {
    // Get the delete file container
    var deleteFileContainer = document.getElementById('deletefileContainer');

    // Get the overlay
    var overlay = document.querySelector('.overlay');

    // Hide the delete file container and overlay
    deleteFileContainer.classList.remove('visible');
    overlay.classList.remove('visible');
}

// Event listener for the delete button
var deleteFileButton = document.createElement('li');
deleteFileButton.className = 'delete-button';
deleteFileButton.textContent = 'Delete';
deleteFileButton.addEventListener('click', function() {
    // Replace 'yourFileName' with the actual file name
    showDeleteFileContainer('yourFileName');
});

// Event listener for the cancel button in the delete file container
var cancelDeleteFileButton = document.getElementById('deletecontainerfile-cancelButton');
cancelDeleteFileButton.addEventListener('click', hideDeleteFileContainer);

// Event listener for the close button in the delete file container
var closeDeleteFileButton = document.getElementById('deletefilecontainer-closeButton');
closeDeleteFileButton.addEventListener('click', hideDeleteFileContainer);

// Event listener for the confirm delete button in the delete file container
var confirmDeleteFileButton = document.getElementById('deletefile-button');
confirmDeleteFileButton.addEventListener('click', function() {
    // Perform the delete file action or call the necessary function
    // You can implement the logic to send the request to delete the file
    // and then hide the delete file container
    hideDeleteFileContainer();
});



function RenameFile(event) {
    // Find the closest file-container to the clicked button
    var fileContainer = event.target.closest('.file-container');

    // Check if a file-container was found
    if (fileContainer) {
        // Find the file name span within the file-container
        var fileNameSpan = fileContainer.querySelector('.filename');

        // Check if a file name span was found
        if (fileNameSpan) {
            // Create an input element
            var fileNameInput = document.createElement('input');
            fileNameInput.type = 'text';
            fileNameInput.className = 'renameinput';
            fileNameInput.value = fileNameSpan.textContent;

            // Replace the file name span with the input element
            fileNameSpan.parentNode.replaceChild(fileNameInput, fileNameSpan);

            // Add event listener for key press events on the input
            fileNameInput.addEventListener('keyup', function handleKeyup(event) {
                if (event.key === 'Enter') {
                    // Save the input and convert it back to a span
                    var newFileNameSpan = document.createElement('span');
                    newFileNameSpan.className = 'filename';
                    newFileNameSpan.textContent = fileNameInput.value;

                    // Replace the input with the new span
                    fileNameInput.parentNode.replaceChild(newFileNameSpan, fileNameInput);

                    // Remove the keyup event listener to avoid triggering it again
                    fileNameInput.removeEventListener('keyup', handleKeyup);

                    // Send the updated data to the server
                    sendRenameFileRequest(fileContainer.dataset.fileId, fileNameInput.value);
                } else if (event.key === 'Escape') {
                    // Restore the original span if the user presses Escape
                    fileNameInput.parentNode.replaceChild(fileNameSpan, fileNameInput);
                    
                    // Remove the keyup event listener to avoid triggering it again
                    fileNameInput.removeEventListener('keyup', handleKeyup);
                }
            });

            // Stop the propagation of the click event on fileNameInput
            fileNameInput.addEventListener('click', function (event) {
                event.stopPropagation();
            });

            // Focus on the input element
            fileNameInput.focus();
        }
    }
}



function sendRenameFileRequest(fileId, newFileName) {
    // Set up the AJAX request
    var xhr = new XMLHttpRequest();
    var url = 'functions.php'; // Adjust the URL based on your file structure

    // Prepare the data to be sent
    var data = new FormData();
    data.append('action', 'RenameFile');
    data.append('fileId', fileId);
    data.append('newFileName', newFileName);

    // Configure the request
    xhr.open('POST', url, true);

    // Set up the callback function to handle the response
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            // Handle the server response here
            console.log(xhr.responseText);
        }
    };

    // Send the request with the data
    xhr.send(data);
}



function sendDeleteFileRequest(fileId, fileContainer) {
    // Create a new XMLHttpRequest object
    var xhr = new XMLHttpRequest();

    // Configure it: POST-request for the specified URL /functions.php
    xhr.open('POST', 'functions.php', true);

    // Set the request header to indicate a form submission
    xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');

    // Define the function to be called when the readyState property changes
    xhr.onreadystatechange = function () {
        // Check if the request is complete
        if (xhr.readyState == 4) {
            // Log the raw response from the server
            console.log('Raw response:', xhr.responseText);

            // Check if the status is OK (200)
            if (xhr.status == 200) {
                // Parse the response from the server
                var response;
                try {
                    response = JSON.parse(xhr.responseText);

                    // Check the response for success or error
                    if (response.result === 'success') {
                        // Hide the delete file container, remove the file container, and sort files
                        hideDeleteFileContainer();
                        fileContainer.remove();
                        sortFilesAlphabetically();
                        console.log('File deleted successfully');
                    } else {
                        // Handle error, e.g., display an error message
                        fileContainer.remove();
                        console.error('Error deleting file:', response.error);
                    }
                } catch (e) {
                    // Handle parsing error
                    fileContainer.remove();
                    console.error('Error parsing JSON:', e);
                }
            }
        }
    };

    // Create the data to be sent with the request
    var data = 'action=deleteFile&fileId=' + fileId;

    // Send the request with the data
    xhr.send(data);
}


function generateNewAddedFile(file) {
    var gridView = document.querySelector('.grid-view');

    // Create the file container
    var fileContainer = document.createElement('div');
    fileContainer.className = 'file-container';
    fileContainer.dataset.fileId = file.fileId;

    // Create the file image
    var fileImage = document.createElement('div');
    fileImage.className = 'file-image';

    var fileType;
    if (file.fileName.match(/\.(png|jpg|jpeg|avif)$/i)) {
        fileType = 'image';
    } else if (file.fileName.match(/\.(mp3|wav|aac|flac|wma|aiff|m4a|opus)$/i)) {
        fileType = 'audio';
    } else if (file.fileName.match(/\.(mp4|avi|mkv|mov|wmv|flv|webm|3gp)$/i)) {
        fileType = 'video';
    } else if (file.fileName.match(/\.(pdf|doc|docx|ppt|pptx)$/i)) {
        fileType = 'document';
    } else {
        fileType = 'unknown'; // Add a default image for unknown file types
    }

    // Set the image source based on the file type
    switch (fileType) {
        case 'image':
            fileImage.innerHTML = '<img src="/Note/content/assets/images/imagefile.png">';
            break;
        case 'audio':
            fileImage.innerHTML = '<img src="/Note/content/assets/images/audiofile.png">';
            break;
        case 'video':
            fileImage.innerHTML = '<img src="/Note/content/assets/images/videofile.png">';
            break;
        case 'document':
            fileImage.innerHTML = '<img src="/Note/content/assets/images/reportfile.png">';
            break;
        default:
            fileImage.innerHTML = '<img src="/Note/content/assets/images/unknownfile.png">';
            break;
    }

    // Create the file name and options container
    var fileNameOptions = document.createElement('div');
    fileNameOptions.className = 'file-name-options';

    // Create the file name span
    var fileNameSpan = document.createElement('span');
    fileNameSpan.className = 'filename';
    fileNameSpan.textContent = file.fileName;

    // Create the more options button
    var moreOptionsButton = document.createElement('button');
    moreOptionsButton.className = 'moreoptions-file';
    moreOptionsButton.innerHTML = '<img src="/Note/content/assets/images/moreoptions.png">';

    // Create the options container with a unique ID
    var fileOptionsContainer = document.createElement('div');
    fileOptionsContainer.className = 'file-options-container';
    fileOptionsContainer.id = 'fileOptionsContainer_' + file.fileId; // Use fileId for uniqueness

    // Create the options list
    var fileOptionsList = document.createElement('ul');

    // Create the rename button
    var renameFileButton = document.createElement('li');
    renameFileButton.className = 'rename-button';
    renameFileButton.textContent = 'Rename';

    renameFileButton.addEventListener('click', function (event) {
        event.stopPropagation();
        // Call the RenameFile function when the Rename button is clicked
        RenameFile(event);
    });

    // Create the horizontal rule
    var horizontalFileRule = document.createElement('hr');

    // Create the delete button
    var deleteFileButton = document.createElement('li');
    deleteFileButton.className = 'delete-button';
    deleteFileButton.textContent = 'Delete';

    deleteFileButton.addEventListener('click', function (event) {
        event.stopPropagation();
        // Replace 'yourFileName' with the actual file name
        showDeleteFileContainer(file.fileName);

        // Add an event listener to the delete button inside the delete container
        document.getElementById('deletefile-button').addEventListener('click', function () {
            // Remove the event listener to avoid multiple calls
            document.getElementById('deletefile-button').removeEventListener('click', this);

            // Proceed with the deletion
            sendDeleteFileRequest(file.fileId, fileContainer);
        });
    });

    // Append elements to the options list
    fileOptionsList.appendChild(renameFileButton);
    fileOptionsList.appendChild(horizontalFileRule);
    fileOptionsList.appendChild(deleteFileButton);
    fileOptionsContainer.appendChild(fileOptionsList);

    // Append elements to the file container
    fileNameOptions.appendChild(fileNameSpan);
    if (userRole === 'admin') {
        fileNameOptions.appendChild(moreOptionsButton);
        fileNameOptions.appendChild(fileOptionsContainer);
    }
    fileContainer.appendChild(fileImage);
    fileContainer.appendChild(fileNameOptions);
    moreOptionsButton.addEventListener('click', displayFileMoreOptions);

    // Append the file container to the grid
    gridView.appendChild(fileContainer);
    sortFilesAlphabetically();
    
}


// Function to send the add file request
function SendAddFileRequest(topicId, filename, file) {
    // Create a new FormData object
    var formData = new FormData();

    console.log('Sending Add File Request with Topic ID:', topicId);


    // Append the parameters to the FormData
    formData.append('action', 'addNewFile');
    formData.append('topicId', topicId);
    formData.append('filename', filename);

    // Append the file to FormData
    formData.append('file', file);

    // Create a new XMLHttpRequest object
    var xhr = new XMLHttpRequest();

    // Set up the request
    xhr.open('POST', 'functions.php', true);

    // Set up a callback function to handle the response
    xhr.onreadystatechange = function () {
        if (xhr.readyState === XMLHttpRequest.DONE) {
            if (xhr.status === 200) {
                // Request was successful
                console.log(xhr.responseText);

                // Parse the JSON response
                var response = JSON.parse(xhr.responseText);

                // Check for errors
                if (response.error) {
                    console.error('Error:', response.error);
                } else {
                    // Successfully added a new file
                    console.log('New file added:', response);
                    generateNewAddedFile(response);

                   
                }
            } else {
                // Request failed
                console.error('Request failed with status:', xhr.status);
            }
        }
    };

    // Send the request with the FormData
    xhr.send(formData);
}

function downloadFile(filePath) {
    // Assuming filePath is a valid path to the file on the server

    // Retrieve the file name from the path
    var fileName = filePath.split('/').pop();

    // Create a virtual link to trigger the download
    var downloadLink = document.createElement('a');
    downloadLink.href = filePath;
    downloadLink.download = fileName;

    // Append the link to the body and trigger a click
    document.body.appendChild(downloadLink);
    downloadLink.click();

    // Remove the link from the body
    document.body.removeChild(downloadLink);
}



// Define the function to update the topic files
function updateTopicFiles(response) {
    // Get the grid container
    var gridView = document.querySelector('.grid-view');
    var topicContainers = document.querySelectorAll('.topic-container');
    var deleteFileButton = document.getElementById('deletefile-button');

    // Clear the existing content
    gridView.innerHTML = '';

    // Check if response is defined and has a length property
    if (response && response.length) {
        updateBackButton(true);

        // Loop through each file and create HTML elements
        response.forEach(function (file, index) {
            var fileId = file.fileId;
            var fileName = file.fileName;
            var filePath = file.filePath;
            var subjectId = file.subjectId;
            var topicId = file.topicId;

            // Create the file container
            var fileContainer = document.createElement('div');
            fileContainer.className = 'file-container';
            fileContainer.dataset.fileId = fileId;

            // Create the file image
            var fileImage = document.createElement('div');
            fileImage.className = 'file-image';

             // Get the file extension from the fileName
            var fileExtension = fileName.split('.').pop().toLowerCase();

            // Set the default image source
            var defaultImageSrc = '/Note/content/assets/images/pdf-file.png';

            // Check the file name for specific keywords and update the image source accordingly
            if (fileName.match(/\b(?:png|jpg|jpeg|avif)\b/i)) {
                defaultImageSrc = '/Note/content/assets/images/imagefile.png';
            } else if (fileName.match(/\b(?:mp3|wav|aac|flac|wma|aiff|m4a|opus)\b/i)) {
                defaultImageSrc = '/Note/content/assets/images/audiofile.png';
            } else if (fileName.match(/\b(?:mp4|avi|mkv|mov|wmv|flv|webm|3gp)\b/i)) {
                defaultImageSrc = '/Note/content/assets/images/videofile.png';
            } else if (fileName.match(/\b(?:report|pdf|docx|doc|pptx|ppt|xls|xlsx)\b/i)) {
                defaultImageSrc = '/Note/content/assets/images/reportfile.png';
            }

            fileImage.innerHTML = '<img src="' + defaultImageSrc + '">';

            // Create the file name and options container
            var fileNameOptions = document.createElement('div');
            fileNameOptions.className = 'file-name-options';

            // Create the file name span
            var fileNameSpan = document.createElement('span');
            fileNameSpan.className = 'filename';
            fileNameSpan.textContent = fileName;
            
            // Create the more options button
            var moreOptionsButton = document.createElement('button');
            moreOptionsButton.className = 'moreoptions-file';
            moreOptionsButton.innerHTML = '<img src="/Note/content/assets/images/moreoptions.png">';

            // Create the options container with a unique ID
            var fileOptionsContainer = document.createElement('div');
            fileOptionsContainer.className = 'file-options-container';
            fileOptionsContainer.id = 'fileOptionsContainer_' + index;

            // Create the options list
            var fileOptionsList = document.createElement('ul');

            // Create the rename button
            var renameFileButton = document.createElement('li');
            renameFileButton.className = 'rename-button';
            renameFileButton.textContent = 'Rename';


            renameFileButton.addEventListener('click', function (event) {
            // Call the RenameFile function when the Rename button is clicked
            RenameFile(event);

            event.stopPropagation();
            });


            // Create the horizontal rule
            var horizontalFileRule = document.createElement('hr');

            // Create the delete button
            var deleteFileButton = document.createElement('li');
            deleteFileButton.className = 'delete-button';
            deleteFileButton.textContent = 'Delete';

            deleteFileButton.addEventListener('click', function (event) {
    // Replace 'yourFileName' with the actual file name
    showDeleteFileContainer(fileName);

    event.stopPropagation();

    // Add an event listener to the delete button inside the delete container
    document.getElementById('deletefile-button').addEventListener('click', function () {
        // Remove the event listener to avoid multiple calls
        document.getElementById('deletefile-button').removeEventListener('click', this);
        

        // Proceed with the deletion
        sendDeleteFileRequest(fileId, fileContainer);

       
    });
});




            // Append elements to the options list
            
            fileOptionsList.appendChild(renameFileButton);
            fileOptionsList.appendChild(horizontalFileRule);
            fileOptionsList.appendChild(deleteFileButton);
            fileOptionsContainer.appendChild(fileOptionsList);

            

            // Append elements to the file container
            fileNameOptions.appendChild(fileNameSpan);
            if (userRole === 'admin') {
            fileNameOptions.appendChild(moreOptionsButton);
            fileNameOptions.appendChild(fileOptionsContainer);
            }
            fileContainer.appendChild(fileImage);
            fileContainer.appendChild(fileNameOptions);

            // Append the file container to the grid
            gridView.appendChild(fileContainer);

          

            selectedFileInfo = {
                fileId: fileId,
                fileName: fileName,
                filePath: filePath,
                subjectId: subjectId,
                topicId: topicId
            };

            fileContainer.addEventListener('click', function (event) {
    // Check if the click event target is the moreOptionsButton
    if (!event.target.classList.contains('moreoptions-file')) {
        // If not, proceed with the download
        downloadFile(file.filePath);
    }
});


           
moreOptionsButton.addEventListener('click', function (event) {
    // Stop the event propagation to prevent the fileContainer click event from triggering
    event.stopPropagation();
    
    // Call the displayFileMoreOptions function and pass the event object
    displayFileMoreOptions(event);
});

        });

        sortFilesAlphabetically(selectedFileInfo.topicId);
 



  
        

        // Change the visibility of back buttons
        updateBackButton(true);
    } else{

        if (response && typeof response === 'object' && response.hasOwnProperty('subjectId')) {
            var subjectId = response.subjectId;
            var topicId = response.topicId;
            selectedFileInfo = {
                subjectId: subjectId,
                topicId: topicId
            };

            console.log('Processing file:', response);
        } else {
            console.log('No files or invalid response:', response);
        }

        if (userRole === 'admin') {
          // Create the 'add-topicfile-container' div
          var addTopicFileContainer = document.createElement('div');
            addTopicFileContainer.className = 'add-topicfile-container';

            // Create the image element
            var addFileImage = document.createElement('img');
            addFileImage.src = '/Note/content/assets/images/files.png'; // Set the image source

            // Append the image to the 'add-topicfile-container'
            addTopicFileContainer.appendChild(addFileImage);

            // Create the 'addtopicfileinput-container' div
            var addTopicFileInputContainer = document.createElement('div');
            addTopicFileInputContainer.className = 'addtopicfileinput-container';

            // Create the label element
            var fileLabel = document.createElement('label');
            fileLabel.textContent = 'Add a file';

            // Create the input type file
            var fileInput = document.createElement('input');
            fileInput.type = 'file';
            fileInput.id = 'fileInput'; // You can set a unique ID if needed

            

            // Append the label and file input to the 'addtopicfileinput-container'
            addTopicFileInputContainer.appendChild(fileLabel);
            addTopicFileInputContainer.appendChild(fileInput);

            // Append the 'addtopicfileinput-container' to the 'add-topicfile-container'
            addTopicFileContainer.appendChild(addTopicFileInputContainer);

            // Append the 'add-topicfile-container' to the grid
            gridView.appendChild(addTopicFileContainer);

            sortFilesAlphabetically(selectedFileInfo.topicId);

        }else{
            // Display a message if no files are available
        gridView.innerHTML = '<div class="outoffile-container"><img src="/Note/content/assets/images/outofnotes.png" class="outoffile-image" alt="Out of Notes Image"><h3 class="outoffile-header">No available notes for now.</h3></div>';

        }

        

        // Change the visibility of back buttons
        updateBackButton(true);
       

    }
}



var backButtonToTopic = document.querySelector('.back-to-topic');
if (backButtonToTopic) {
    backButtonToTopic.addEventListener('click', function () {
        console.log('Back to topic button clicked');

        // Remove the 'invisible' class from all topic containers
        var topicContainers = document.querySelectorAll('.topic-container');
        topicContainers.forEach(function (container) {
            container.style.display = 'block';
        });

        // Hide file containers
        var fileContainers = document.querySelectorAll('.file-container');
        fileContainers.forEach(function (container) {
            container.style.display = 'none';
        });

        // Change the visibility of back buttons
        updateBackButton(false);
        console.log('Visibility updated');

        // Trigger the process to update the topic container
        if (selectedFileInfo && selectedFileInfo.subjectId) {
            // Use selectedFileInfo.subjectId instead of selectedSubjectId
            sendSelectedSubjectId(selectedFileInfo.subjectId);
        } else {
            console.log('Error: Subject ID not available');
        }
    });
} else {
    console.log('Error: back-to-topic button not found');
}


function enableAddTopicButton() {
    var addTopicButton = document.querySelector('.add-topic-button');
    addTopicButton.disabled = false;
}

function disableAddTopicButton() {
    var addTopicButton = document.querySelector('.add-topic-button');
    addTopicButton.disabled = true;
}


function retrieveComments(subjectId) {
    var action = "getCommentsBySubject";

    $.ajax({
        type: "POST",
        url: "functions.php",
        data: { action: action, subject_id: subjectId },
        success: function(response) {
            // Parse the JSON response
            var comments = JSON.parse(response);
            console.log('response:', response);

            // Call generateUserComment with the entire array of comments
            generateUserComment(comments);
        },
        error: function(error) {
            console.error("Ajax request failed: " + error.statusText);
        }
    });
}

var userStudentID = <?php echo json_encode($userStudentID); ?>;
var commentCount = 0; 
var comment_info = [];
function generateUserComment(response) {
    // Check if response exists and has length
    if (response && response.length) {
        response.forEach(function (comment, index) { 
            console.log('studentid:',comment.studentID);
       
                
            // Create a container for the user comment  
            var commentContainer = document.createElement('div');
            commentContainer.classList.add('user-comment-containers');

            commentContainer.commentInfo = comment;

            console.log('Comment Info for Container ' + index + ':', commentContainer.commentInfo)

            // Create the circular user profile container
            var userProfileContainer = document.createElement('div');
            userProfileContainer.classList.add('yourcomment-circular-user-profile');

            // Create the user profile picture element
            var userProfilePic = document.createElement('img');
            userProfilePic.classList.add('usercomment-profilepic');
            userProfilePic.src = comment.userimage ? comment.userimage : '/default-profile-image.png';

            // Append the user profile picture to its container
            userProfileContainer.appendChild(userProfilePic);

            // Create the user comment details container
            var commentDetailsContainer = document.createElement('div');
            commentDetailsContainer.classList.add('usercomment-details');

            // Create the user comment full name and date container
            var fullNameDateContainer = document.createElement('div');
            fullNameDateContainer.classList.add('usercommentfullnamedate-cont');

            // Create the full name span
            var fullNameSpan = document.createElement('span');
            fullNameSpan.classList.add('usercomment-fullname');
            fullNameSpan.textContent = '@' + comment.fullname;


            if (comment.userType === 'admin') {
    // Create an image element for admin
    var adminTickImg = document.createElement('img');
    adminTickImg.classList.add('admin-tick');
    adminTickImg.src = '/Note/content/assets/images/verified.png';  // Set the source of the image
    fullNameDateContainer.appendChild(adminTickImg);
}



            // Create the date span
            var dateSpan = document.createElement('span');
            dateSpan.classList.add('usercomment-date');
            dateSpan.textContent = comment.comment_date;  // Replace 'date' with the actual property in your response

            // Create the edited span
            var editedSpan = document.createElement('span');
            editedSpan.classList.add('usercomment-edited');
            editedSpan.textContent = comment.is_edited ? '(Edited)' : '';

        
            fullNameDateContainer.appendChild(fullNameSpan);
            fullNameDateContainer.appendChild(dateSpan);
            fullNameDateContainer.appendChild(editedSpan);

            if (comment.studentID === userStudentID || userRole === 'admin') {
                // Create the edit comment button
                var editCommentButton = document.createElement('button');
                editCommentButton.classList.add('edit-comment-button');
                var editCommentImg = document.createElement('img');
                editCommentImg.src = '/Note/content/assets/images/moreoptions.png';  // Set the source of the image
                editCommentButton.appendChild(editCommentImg);
                editCommentButton.addEventListener('click', displayCommentOptions);


            // Append the elements to the full name and date container
            fullNameDateContainer.appendChild(editCommentButton);

            }


            

            // Create the user comment content container
            var commentContentContainer = document.createElement('div');
            commentContentContainer.classList.add('usercomment-commentcontent-cont');

            // Create the comment content paragraph
            var commentContent = document.createElement('p');
            commentContent.classList.add('usercomment-commentcontent');
            commentContent.textContent = comment.comment_content;  // Replace 'comment_content' with the actual property in your response

            // Append the comment content to its container
            commentContentContainer.appendChild(commentContent);

            // Create the like, dislike, and reply container
            var likeDislikeReplyContainer = document.createElement('div');
            likeDislikeReplyContainer.classList.add('like-dislike-reply-cont');

            // Create the like button
            var likeButton = document.createElement('button');
            likeButton.classList.add('usercomment-likebutton');
            var likeImg = document.createElement('img');
            likeImg.src = '/Note/content/assets/images/likecomment.png';  // Set the source of the image
            likeButton.appendChild(likeImg);

            // Create the dislike button
            var dislikeButton = document.createElement('button');
            dislikeButton.classList.add('usercomment-dislikebutton');
            var dislikeImg = document.createElement('img');
            dislikeImg.src = '/Note/content/assets/images/dislikecomment.png';  // Set the source of the image
            dislikeButton.appendChild(dislikeImg);

            // Create the reply button
            var replyButton = document.createElement('button');
            replyButton.classList.add('usercomment-reply-button');
            replyButton.textContent = 'Reply';

            // Append the buttons to the like, dislike, and reply container
            likeDislikeReplyContainer.appendChild(likeButton);
            likeDislikeReplyContainer.appendChild(dislikeButton);
            likeDislikeReplyContainer.appendChild(replyButton);

            // Append all the elements to the user comment container
            commentContainer.appendChild(userProfileContainer);
            commentContainer.appendChild(commentDetailsContainer);
            commentDetailsContainer.appendChild(fullNameDateContainer);
            commentDetailsContainer.appendChild(commentContentContainer);
            commentDetailsContainer.appendChild(likeDislikeReplyContainer);

              // Create the options container with a unique ID
            var optionsContainer = document.createElement('div');
            optionsContainer.className = 'comment-options-container';
            optionsContainer.id = 'optionsContainer_' + index;

            // Create the options list
            var optionsList = document.createElement('ul');

            // Create the edit button
            var EditButton = document.createElement('li');
            EditButton.className = 'rename-button';
            EditButton.textContent = 'Edit';
            EditButton.addEventListener('click', function (event) {
                // Access comment information from commentContainer
                console.log('Comment Info:', commentContainer.commentInfo);
                editComment(event, commentContainer.commentInfo.comment_id);
            });
            // Create the horizontal rule
            var horizontalRule = document.createElement('hr');

            // Create the delete button
            var deleteButton = document.createElement('li');
            deleteButton.className = 'delete-button';
            deleteButton.textContent = 'Delete';

            deleteButton.addEventListener('click', function () {
    // Get the comment ID from the data attribute of the parent container
    var commentContainer = deleteButton.closest('.user-comment-containers');
    var commentId =  commentContainer.commentInfo.comment_id;
    console.log('data passed to delete:',commentId);

    // Call the deleteComment function with the comment ID
    deleteComment(commentId, commentContainer);
});

            // Append options to the options list
            optionsList.appendChild(EditButton);
            optionsList.appendChild(horizontalRule);
            optionsList.appendChild(deleteButton);

            // Append the options list to the options container
            optionsContainer.appendChild(optionsList);

            // Append the options container to the user comment container
            commentContainer.appendChild(optionsContainer);

            // Append the user comment container to the existing 'all-comments' div
            document.querySelector('.all-comments').appendChild(commentContainer);

            comment_info.push(comment);
        });

        console.log('Comment Info Array:', comment_info);
        // Update comment count
        commentCount = document.querySelectorAll('.user-comment-containers').length;
        updateCommentCount(commentCount);
    }else{
        commentCount = 0;
        updateCommentCount(commentCount);


        comment_info.push({
        comments: [],
        subject_id: response.subject_id
    });



    }
}


function displayCommentOptions(event) {
    // Find the closest user-comment-containers to the clicked button
    var commentContainer = event.target.closest('.user-comment-containers');

    // Check if a user-comment-containers was found
    if (commentContainer) {
        // Find the options container within the user-comment-containers
        var commentOptionsContainer = commentContainer.querySelector('.comment-options-container');

        // Toggle the visibility if the options container is found
        if (commentOptionsContainer) {
            commentOptionsContainer.classList.toggle('visible');
        }

        // Stop the click event from propagating up the DOM tree
        event.stopPropagation();

        // Add event listener to close options container when clicking outside
        document.addEventListener('click', function closeOptionsContainer(e) {
            // Check if the clicked element is not within the comment-options-container
            if (!commentOptionsContainer.contains(e.target)) {
                // Close the options container
                commentOptionsContainer.classList.remove('visible');
                // Remove the event listener to avoid further checks
                document.removeEventListener('click', closeOptionsContainer);
            }
        });
    }
}




function updateCommentCount() {

    // Update the text content of the element with the comment count
    var commentCountElement = document.getElementById('commentcount');
    commentCountElement.textContent = commentCount + ' Comment' + (commentCount !== 1 ? 's' : '');
}


function initializeCommentCount() {
    // Initialize the comment count element
    updateCommentCount();
}

// Call the initialization function
initializeCommentCount();

function editComment(event, commentId) {
    // Find the closest user-comment-containers to the clicked button
    var commentContainer = event.target.closest('.user-comment-containers');

    // Check if a user-comment-containers was found
    if (commentContainer) {
        // Find the comment content paragraph within the user-comment-containers
        var commentContentParagraph = commentContainer.querySelector('.usercomment-commentcontent');

        // Check if a comment content paragraph was found
        if (commentContentParagraph) {
            // Create a textarea element
            var commentContentTextarea = document.createElement('textarea');
            commentContentTextarea.classList.add('editcomment-input-style');
            commentContentTextarea.value = commentContentParagraph.innerText;


            // Replace the comment content paragraph with the textarea
            commentContentParagraph.parentNode.replaceChild(commentContentTextarea, commentContentParagraph);

            // Set initial height
            commentContentTextarea.style.height = 'auto';

            // Add event listener for input events on the textarea
            commentContentTextarea.addEventListener('input', function () {
                this.style.height = 'auto'; // Set the initial height
                this.style.height = (this.scrollHeight) + 'px';

                
            });
            // Add event listener for key press events on the textarea
            hideOptionsContainer(commentContainer);
            commentContentTextarea.addEventListener('keyup', function (event) {
                if (event.key === 'Enter' && !event.shiftKey) {
                    // Save the textarea content and convert it back to a paragraph
                    var newCommentContentParagraph = document.createElement('p');
                    newCommentContentParagraph.classList.add('usercomment-commentcontent');
                    newCommentContentParagraph.innerText = commentContentTextarea.value;


                    // Replace the textarea with the new paragraph
                    commentContentTextarea.parentNode.replaceChild(newCommentContentParagraph, commentContentTextarea);

                    // Extract the comment_id from the dataset
                    var extractedCommentId = commentContainer.commentInfo.comment_id;

                    // Send the updated data to the server
                    sendEditCommentRequest(extractedCommentId, commentContentTextarea.value);

                    hideOptionsContainer(commentContainer);
                } else if (event.key === 'Escape') {
                    // Restore the original paragraph if the user presses Escape
                    commentContentTextarea.parentNode.replaceChild(commentContentParagraph, commentContentTextarea);
                    hideOptionsContainer(commentContainer);
                }
            });

            // Stop the click event from propagating up the DOM tree
            commentContentTextarea.addEventListener('click', function (event) {
                event.stopPropagation();
            });
        }
    }
}

function deleteComment(commentId, commentContainer) {
    // Make the AJAX request to delete the comment

    $.ajax({
        type: 'POST',
        url: 'functions.php',
        data: {
            action: 'deleteComment',
            commentId: commentId
        },
        success: function (response) {
            // Handle the success response if needed
            console.log('Delete Comment Success:', response);
            commentContainer.remove();

      
        },
        error: function (error) {
            // Handle the error response if needed
            console.error('Delete Comment Error:', error.statusText);
        
        }
    });
}

// Function to remove the deleted comment from the UI
function removeCommentFromUI(commentId) {
    var commentContainer = document.querySelector('.user-comment-containers');

    if (commentContainer && commentContainer.commentInfo && commentContainer.commentInfo.comment_id == commentId) {
        // Remove the comment container from the UI
        commentContainer.remove();

        // Update comment count
        var commentCount = document.querySelectorAll('.user-comment-containers').length;
        updateCommentCount(commentCount);
    }
}



function sendEditCommentRequest(commentId, editedCommentContent) {
    // Log the commentId value (you can remove or adjust this in a production environment)
    console.log('Sending commentId to server:', commentId);

    console.log("this is what u said:", editedCommentContent);

    // Prepare data for the AJAX request
    var data = {
        action: 'editComment',
        commentId: commentId,
        edited_comment_content: editedCommentContent
    };

    console.log('Sending data to server:', data);

    // Make the AJAX request
    $.ajax({
        type: 'POST',
        url: 'functions.php',
        data: data,
        success: function (response) {
            // Handle the success response if needed
            console.log('Edit Comment Success:', response);
        },
        error: function (error) {
            // Handle the error response if needed
            console.error('Edit Comment Error:', error.statusText);
        }
    });
}


function gatherCommentData() {
    // Get the comment content from the textarea
    var commentContent = document.getElementById('yourcommentinput').value;
    var subjectID = comment_info.length > 0 ? comment_info[0].subject_id : null;

    // Access the subjectID from generateUserComment function
    // Replace 'yourSubjectIDProperty' with the actual property name in your response
    console.log('commentContent:', commentContent);
    console.log('subjectID:', subjectID);
    console.log('userStudentID:', subjectID);

    

    // Call addComment with the gathered data
    addComment(commentContent, userStudentID, subjectID);
}

// Attach an event listener to the comment button
document.getElementById('yrcommentbtn').addEventListener('click', function () {
    // Call gatherCommentData when the button is clicked
    gatherCommentData();

    // Clear the textarea
    document.getElementById('yourcommentinput').value = "";
});



function addComment(commentContent, studentID, subjectID) {
    // Prepare data for the AJAX request
    var data = {
        action: 'addComment',
        commentContent: commentContent,
        studentID: studentID,
        subjectID: subjectID
    };

    console.log('data:', data);

    // Make the AJAX request
    $.ajax({
        type: 'POST',
        url: 'functions.php',
        data: data,
        success: function (response) {
            // Handle the success response
            console.log('Add Comment Success:', response);

            var commentDetailsObject = JSON.parse(response);

            // Call the generateNewCommentContainer function with the new comment data
            generateNewCommentContainer(commentDetailsObject);

        
            
            // You can perform additional actions after successfully adding the comment if needed
        },
        error: function (error) {
            // Handle the error response if needed
            console.error('Add Comment Error:', error.statusText);
        }
    });
}

var commentDetailsArray = [];
function generateNewCommentContainer(commentDetails) {
    commentDetailsArray.push(commentDetails);
    console.log("commentDetailsArray:", commentDetailsArray);
        // Create a container for the new user comment
        var commentContainer = document.createElement('div');
        commentContainer.classList.add('user-comment-containers');

    // Create the circular user profile container
    var userProfileContainer = document.createElement('div');
    userProfileContainer.classList.add('userdetails-circular-user-profile');

    // Create the user profile picture elementy
    var userProfilePic = document.createElement('img');
    userProfilePic.classList.add('usercomment-profilepic');
    userProfilePic.src = commentDetails.userimage ? commentDetails.userimage : '/default-profile-image.png';

    // Append the user profile picture to its container
    userProfileContainer.appendChild(userProfilePic);

    // Create the user comment details container
    var commentDetailsContainer = document.createElement('div');
    commentDetailsContainer.classList.add('usercomment-details');

    // Create the user comment full name and date container
    var fullNameDateContainer = document.createElement('div');
    fullNameDateContainer.classList.add('usercommentfullnamedate-cont');

    // Create the full name span
    var fullNameSpan = document.createElement('span');
    fullNameSpan.classList.add('usercomment-fullname');
    fullNameSpan.textContent = '@' + commentDetails.fullname;

    // Check if the user is an admin
    if (commentDetails.userType === 'admin') {
        // Create an image element for admin
        var adminTickImg = document.createElement('img');
        adminTickImg.classList.add('admin-tick');
        adminTickImg.src = '/Note/content/assets/images/verified.png';
        fullNameDateContainer.appendChild(adminTickImg);
    }

    // Create the date span
    var dateSpan = document.createElement('span');
    dateSpan.classList.add('usercomment-date');
    dateSpan.textContent = commentDetails.comment_date; // Replace 'comment_date' with the actual property in your response

    // Create the edited span
    var editedSpan = document.createElement('span');
    editedSpan.classList.add('usercomment-edited');
    editedSpan.textContent = commentDetails.is_edited ? '(Edited)' : '';

    fullNameDateContainer.appendChild(fullNameSpan);
    fullNameDateContainer.appendChild(dateSpan);
    fullNameDateContainer.appendChild(editedSpan);

    if (commentDetails.studentID === userStudentID) {
                // Create the edit comment button
                var editCommentButton = document.createElement('button');
                editCommentButton.classList.add('edit-comment-button');
                var editCommentImg = document.createElement('img');
                editCommentImg.src = '/Note/content/assets/images/moreoptions.png';  // Set the source of the image
                editCommentButton.appendChild(editCommentImg);
                editCommentButton.addEventListener('click', displayCommentOptions);


            // Append the elements to the full name and date container
            fullNameDateContainer.appendChild(editCommentButton);

            }


    

    // Create the user comment content container
    var commentContentContainer = document.createElement('div');
    commentContentContainer.classList.add('usercomment-commentcontent-cont');

    // Create the comment content paragraph
    var commentContent = document.createElement('p');
    commentContent.classList.add('usercomment-commentcontent');
    commentContent.textContent = commentDetails.comment_content;

    // Append the comment content to its container
    commentContentContainer.appendChild(commentContent);

    // Create the like, dislike, and reply container
    var likeDislikeReplyContainer = document.createElement('div');
    likeDislikeReplyContainer.classList.add('like-dislike-reply-cont');

    // Create the like button
    var likeButton = document.createElement('button');
    likeButton.classList.add('usercomment-likebutton');
    var likeImg = document.createElement('img');
    likeImg.src = '/Note/content/assets/images/likecomment.png';
    likeButton.appendChild(likeImg);

    // Create the dislike button
    var dislikeButton = document.createElement('button');
    dislikeButton.classList.add('usercomment-dislikebutton');
    var dislikeImg = document.createElement('img');
    dislikeImg.src = '/Note/content/assets/images/dislikecomment.png';
    dislikeButton.appendChild(dislikeImg);

    // Create the reply button
    var replyButton = document.createElement('button');
    replyButton.classList.add('usercomment-reply-button');
    replyButton.textContent = 'Reply';

    // Append the buttons to the like, dislike, and reply container
    likeDislikeReplyContainer.appendChild(likeButton);
    likeDislikeReplyContainer.appendChild(dislikeButton);
    likeDislikeReplyContainer.appendChild(replyButton);

    // Append all the elements to the user comment container
    commentContainer.appendChild(userProfileContainer);
    commentContainer.appendChild(commentDetailsContainer);
    commentDetailsContainer.appendChild(fullNameDateContainer);
    commentDetailsContainer.appendChild(commentContentContainer);
    commentDetailsContainer.appendChild(likeDislikeReplyContainer);




    // Create the options container with a unique ID
    var optionsContainer = document.createElement('div');
    optionsContainer.className = 'comment-options-container';
    optionsContainer.id = 'optionsContainer_' + commentDetails.comment_id;

    // Create the options list
    var optionsList = document.createElement('ul');

    // Create the edit button
    var editButton = document.createElement('li');
    editButton.className = 'rename-button';
    editButton.textContent = 'Edit';
    editButton.addEventListener('click', function (event) {
        // Access comment information from commentContainer
        console.log('Comment Info:', commentDetails);
        var commentId = commentDetails.comment_id;
        editComment(event, commentId);
    });

    // Create the horizontal rule
    var horizontalRule = document.createElement('hr');

    // Create the delete button
    var deleteButton = document.createElement('li');
    deleteButton.className = 'delete-button';
    deleteButton.textContent = 'Delete';

    deleteButton.addEventListener('click', function () {
        // Get the comment ID from the data attribute of the parent container
        var commentContainer = deleteButton.closest('.user-comment-containers');
        var commentId = commentDetails.comment_id;
        console.log('data passed to delete:', commentId);


        deleteComment(commentId, commentContainer);
    });

    // Append options to the options list
    optionsList.appendChild(editButton);
    optionsList.appendChild(horizontalRule);
    optionsList.appendChild(deleteButton);

    // Append the options list to the options container
    optionsContainer.appendChild(optionsList);

    // Append the options container to the user comment container
    commentContainer.appendChild(optionsContainer);

    // Append the user comment container to the existing 'all-comments' div
    document.querySelector('.all-comments').appendChild(commentContainer);
}






function hideOptionsContainer(commentContainer) {
    // Find the options container within the user-comment-containers
    var optionsContainer = commentContainer.querySelector('.comment-options-container');

    // Check if options container was found
    if (optionsContainer) {
        // Hide the options container
        optionsContainer.classList.remove('visible');
    }
}


// Event listener for clicks on the "Add Topic" button and its image
document.addEventListener('click', function (event) {
    if (event.target.classList.contains('add-topic-button') || event.target.parentElement.classList.contains('add-topic-button')) {
        addNewTopic();
    }
});



    rows.forEach(function (row) {
        row.addEventListener('click', toggleContainers);
    });

    // Event listener for the "Return to subject selection" button
    backButton.addEventListener('click', function (event) {
        // Log the subject_id and subject_name when the "Return to subject selection" button is clicked
        var subjectId = topicFileTableContainer.getAttribute('data-subject-id');
        var subjectName = topicFileTableContainer.getAttribute('data-subject-name');

        toggleContainers(event); // Pass the event object to the function
    });
});



</script>

<!-- Your existing HTML code here -->

<script>
  function cancelFunction() {
    const textarea = document.getElementById('yourcommentinput');
    const commentButton = document.getElementById('yrcommentbtn');
    const container = document.querySelector('.yourcomment-emoji-cancelcomment-container');

    container.hidden = true;
    textarea.value = ''; // Reset textarea value to empty

    // Disable the comment button after clearing the textarea
    commentButton.disabled = true;
  }

  document.addEventListener('DOMContentLoaded', function () {
    const textarea = document.getElementById('yourcommentinput');
    const commentButton = document.getElementById('yrcommentbtn');
    const container = document.querySelector('.yourcomment-emoji-cancelcomment-container');
    const Cancelcommentbtn = document.getElementById('cancelyrcommentbtn'); // Rename cancelButton to Cancelcommentbtn

    textarea.addEventListener('input', function () {
      this.style.height = '30px'; // Set the initial height
      this.style.height = (this.scrollHeight) + 'px';

      // Enable or disable the button based on whether the textarea is empty
      commentButton.disabled = this.value.trim() === '';
    });

    textarea.addEventListener('focus', function () {
      container.hidden = false;
    });

    // Attach the cancel function to the Cancelcommentbtn click event
    Cancelcommentbtn.addEventListener('click', cancelFunction);
  });
</script>










</body>
</html>