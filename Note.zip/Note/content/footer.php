<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="./assets/css/styles.css" />
    <link rel="stylesheet" href="./assets/css/style.css" />
	<title>Note</title>
</head>
<body>
    <footer>
        <div class="footer-section-one">
        <img class="main-logo-icon-footer" src="/Note/content/assets/images/mainlogo.png">
 

        <div class="socialmedia-icons">
            <img src="/Note/content/assets/images/facebook-icon.png">
            <img src="/Note/content/assets/images/instagram-icon.png">
            <img src="/Note/content/assets/images/twitter-icon.png">
            <img src="/Note/content/assets/images/linkedin-icon.png">
        </div>
        </div>

        <div class="footer-section-two">
            <h3 class="footer-section-two-header">Team</h3>
            <ul class="footer-section-two-content">
                <li>Vision</li>
                <li>Contact us</li>
                <li>About us</li>
            </ul>
        </div>

        <div class="footer-section-three">
            <h3 class="footer-section-three-header">Daily</h3>
            <ul class="footer-section-three-content">
                <li>Regulation updates</li>
                <li>Collaboration</li>
                <li>News</li>
            </ul>
        </div>

        <div class="footer-section-four">
            <h3 class="footer-section-four-header">Support</h3>
            <ul class="footer-section-four-content">
                <li>Customer support</li>
                <li>Terms & privacy</li>
                <li>FAQs</li>
              
            </ul>
        </div>
        
    </footer>

    <footer class="last-footer">
        <div class="final-homepage-section">
            <div class="privacycookie-policy">
                <a>Privacy policy |</a><a> Cookie policy</a>
            </div>

            <div class="copyright">
                <a>© eznotes, 2023.</a>
                
            </div>

        </div>
    
    </footer>

</body>
</html>