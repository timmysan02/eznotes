<?php include 'server.php'; ?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="./assets/css/styles.css" />
    <link rel="stylesheet" href="./assets/css/style.css" />
	<title>Note</title>
</head>
<body>

    <header class="main-header">
        <div class="main-header-section-one">
        <a href="homepage.php">
        <img class="main-logo" src="/Note/content/assets/images/mainlogo.png" alt="Main Logo">
        </a>
       
        <span class="setting-header">Settings and Management</span>
        </div>

        <div class="main-header-section-two">
            <button class="notification-btn">
                <img src="/Note/content/assets/images/notification.png">
            </button>

            <button class="menu-settings-btn">
                <img src="/Note/content/assets/images/menu.png">
            </button>

        
        </button>

        <?php
        $sessionData = $_SESSION['user'] ?? $_SESSION['admin'] ?? null;

        if (is_array($sessionData)) :
            // Assuming $_SESSION['user']['fullname'] is "Alexander Johns" or $_SESSION['admin']['fullname'] is "John Doe"
            $fullName = $sessionData['fullname'];
            // Split the full name into an array of words
            $fullNameArray = explode(' ', $fullName);
            // Take the first element as the first name
            $firstName = $fullNameArray[0];

            $imagePath = isset($_SESSION['user']) ? '/Note/content/assets/images/user.png' : '/Note/content/assets/images/admin.png';
        ?>
            <button class="user_profile" onclick="toggleUserOptionstwo(event)">
                <div class="circular-user-profile">
                <img src="<?php echo $userImage; ?>">
                </div>
                <span><?php echo $firstName; ?></span>

                <div class="user-options2-container">
                <ul>
                    <li class="manage-account" onclick="redirectusersettings()">Manage account</li>
                    <hr>
                    <li  class="logout-btn" onclick="logout()">Logout</li>
                    <!-- Add more options as needed -->
                </ul>
            </div>

            </button>

        <?php else : ?>
            <a href="signin.php" class="login-main-header-button"> Login</a>
        <?php endif; ?>

        </div>
    </header>

    
    <script src="./assets/js/useroptions.js"></script>
    <script src="./assets/js/usersettings.js"></script>
    <script src="./assets/js/logout.js"></script>
    <script>
    document.addEventListener("DOMContentLoaded", function () {
        // Mocking the userinfoCompare array for demonstration purposes
        var userinfoCompare = <?php echo json_encode($usereditinfoCompare); ?>;
        
        function EditValidationProcess() {
            var inputEmail = document.getElementById("edit-emailinput").value;
            var inputPassword = document.getElementById("passwordInput").value;

      

    

            var isEmailExist = false;
            var isPasswordExist = false;

            // Loop through the userinfoCompare array
            for (var i = 0; i < userinfoCompare.length; i++) {
                var user = userinfoCompare[i];

                if (user.email === inputEmail) {
                    isEmailExist = true;
                    break;
                }

                if (user.password === inputPassword) {
                    isPasswordExist = true;
                    break;
                }
            }

         

            // Set visibility and style based on the result of the comparison for Email
            document.getElementById("edit-emailinput").style.borderColor = isEmailExist ? "red" : "";
            document.getElementById("editemail-message-alert").style.visibility = isEmailExist ? "visible" : "hidden";

            // Set visibility and style based on the result of the comparison for Password
            document.getElementById("editpassword-message-alert").style.visibility = isPasswordExist ? "visible" : "hidden";
            document.getElementById("passwordInput").style.borderColor = isPasswordExist ? "red" : "";

            // Disable the "Save" button if any matches are found
            document.getElementById("edit-userdetails-btn").disabled = isEmailExist || isPasswordExist;
        }

        // Attach the EditValidationProcess function to the input events
        document.getElementById("edit-emailinput").addEventListener("input", EditValidationProcess);
        document.getElementById("passwordInput").addEventListener("input", EditValidationProcess);

        // Run the EditValidationProcess function initially
        EditValidationProcess();
    });
</script>

</body>
</html>